****************************************************************************
		    Fast Ethernet Controller Provider Inc.
		       PCI 10/100 Fast Ethernet Adapter

			   SoftWare Driver Support
			   ~~~~~~~~~~~~~~~~~~~~~~~

	   Copyright (C) 1999 Fast Ethernet Controller Provider Inc.
			     All rights reserved.
****************************************************************************


Product Support
---------------
This release diskette can be used for the following Fast Ethernet Controller
Provider Ethernet adapters:

                  FastNIC Adapter


How to Configue Your PCI adapter
------------------------------
 1. Go to the PCI configuration item in BIOS setup.

 2. For legacy computers please follow the following steps to configure the
    PCI slot:
    
    a). You should know which slot your adapter is plugged in to. Look for
	the physical location of the slot on your PCI motherboard.

    b). Set the field that reads "this device" to "Enable".

    c). Set the field that reads "this item" to "Master". 
	The FastNIC PCI adapter MUST be installed in an expansion slot
	that supports "Bus Master" Refer to your system documentation to
	determine which slots support Bus Mastering.

    d). Some BIOS Setups allow you to select which interrupt line you can 
	use. In our case, select "INT A" for the field that reads "this 
	item".

    e). Select an IRQ of your choice; make sure it does not conflict with
	existing IRQs in use.

    f). Select the "Trigger method" by which the IRQ is assigned or routed
	to the PCI slot. Choose the "level-trigger" option.
	Multiple FastNIC PCI adapters can share the same PCI interrupt and
	all must use INTA with level-trigger mode.

 3. Run the diagnostic program found in the driver diskette. If a problem 
    arises during the installation, contact your dealer or
    Fast Ethernet Controller Provider Inc. for support.



Conflict with Microsoft EMM386
------------------------------
  The PCI adapters can only function with the EMM386.exe memory manager
 program version 4.49 or later. You can verify its version number by 
 entering EMM386 at the DOS Prompt.

  Do not specify the "highscan" option with the EMM386.exe statement in your
 config.sys file, or your system will hang.

  If you run MEMMAKER and select Custom Setup, do not specify "Aggressively
 scan upper memory", or it will automatically insert the HIGHSCAN flag into
 the EMM386 command line. This parameter cannot be manually removed once
 it is installed, doing so will prevent the extended memory manager to
 function properly.




Support for 5 Volt PCI Slots
----------------------------
  The PCI 10/100 Fast Ethernet Adapter currently supports only 5 volt PCI
 slots. Future releases of the adapter will support both 3.3 and 5 volt PCI
 slots.
