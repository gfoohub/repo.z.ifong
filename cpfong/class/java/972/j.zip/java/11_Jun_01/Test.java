abstract interface xx{}
//interface xx{}
