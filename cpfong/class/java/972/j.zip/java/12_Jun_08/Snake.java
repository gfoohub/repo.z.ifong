public class Snake extends Animal{
	public String says(){
		return "hiss";
	}
}
