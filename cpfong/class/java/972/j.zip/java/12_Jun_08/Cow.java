public class Cow extends Animal{
	public String says(){
		return "moo";
	}
}
