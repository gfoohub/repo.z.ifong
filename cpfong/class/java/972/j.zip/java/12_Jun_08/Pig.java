public class Pig extends Animal{
	public String says(){
		return "grunt";
	}
}
