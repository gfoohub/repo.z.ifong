// import gui.Login;
import gui.*;

public class Test{
	Login  l = new Login ();
	Logout l2= new Logout();
}
