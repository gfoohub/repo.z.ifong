public class PriTest{
	public static void main(String args[]){
		PriorityClass p1 = new PriorityClass("Chen");
		PriorityClass p2 = new PriorityClass("Wong");
		p1.start();
		p2.start();
	}
}
