public class Argu_Test{
	public static void main(String args[]){
		System.out.println(
		args[0] + "+" + args[1] + " = " + (Integer.parseInt(args[0])+Integer.parseInt(args[1]))
		);
	}
}

