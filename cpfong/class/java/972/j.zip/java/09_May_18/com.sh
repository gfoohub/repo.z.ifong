#!/bin/sh
javac MyThread.java;javac ThreadMain.java
