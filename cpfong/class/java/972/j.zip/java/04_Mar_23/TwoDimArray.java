public class TwoDimArray{
	public static void main(String args[]){
		int a[][]=new int[2][2];
		int b[][]={{00,01},{10,11},{20,21}};

		for (int i=0; i<3; i++){
			for (int j=0; j<2; j++){
				System.out.print(""+b[i][j]+" ");
			}
			
			System.out.print("\n");
		}
	}
}
