import java.io.*;

public class RuntimeException{
	public static void main(String[] args){
		int a[]=new int[3];
		
		for (int i=0; i<a.length; i++){
			a[i]=0;
		}
		System.exit(0);
	}
}
