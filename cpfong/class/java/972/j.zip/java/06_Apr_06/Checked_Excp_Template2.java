import java.io.*;

public class Checked_Excp_Template2{
        public static void main(String[] args){
                try { BufferedReader inFile = new BufferedReader(new FileReader("c:\\myfile.txt")); }
                catch (FileNotFoundException e){
                        System.out.println("cannot find file");
                        System.exit(1);
                }

        }
}
