//--------STARTEXTRACT=consolejoption.xtr
import javax.swing.*;
public class ConsoleJOptionDemo{
    public static void main(String[] args){
        JOptionPane.showMessageDialog(null, "Hello World");
    }
}
//------------ENDEXTRACT=consolejoption.xtr

 


