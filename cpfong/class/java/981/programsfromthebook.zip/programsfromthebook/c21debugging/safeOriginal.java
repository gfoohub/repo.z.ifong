import java.awt.*;    // 30 oct template
import java.awt.event.*;
import javax.swing.*;

class Hello extends JFrame {

    public static void main (String[] args) {
        int x = 2;
        int y = 3;
        int diameter = 20;

        JOptionPane.showMessageDialog(null, "Hello World!");
        JOptionPane.showMessageDialog(null,
"x = " + x +
            " y = " + y +
            " diameter = " + diameter);

        JOptionPane.showMessageDialog(null, "Goodbye");
        System.exit(0);
    }
}
