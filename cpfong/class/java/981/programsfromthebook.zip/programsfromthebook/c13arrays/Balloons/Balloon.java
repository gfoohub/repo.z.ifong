import java.awt.*;

public class Balloon {

    private int x; 
    private int y; 
    private int diameter; 

    public Balloon(int initialX, int initialY, int initialDiameter) {
        x = initialX;
        y = initialY;
        diameter = initialDiameter;
    }

    public void changeSize(int change) {
        diameter = diameter + change;
    }

    public void display(Graphics paper) {
        paper.drawOval(x, y, diameter, diameter);
    }

}

