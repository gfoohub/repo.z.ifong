import java.awt.*;
import java.awt.event.*;
import javax.swing.*;   

public class C2Inserts extends JFrame {

    public static void main (String[] args) {
//-----------------STARTEXTRACT=optionfinishing.xtr
        JOptionPane.showMessageDialog(null, "Finishing now");
//-----------------ENDEXTRACT=optionfinishing.xtr
        System.exit(0);
    }
}

