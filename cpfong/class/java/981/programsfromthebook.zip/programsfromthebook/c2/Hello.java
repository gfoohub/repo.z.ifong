import java.awt.*; 
import java.awt.event.*;
import javax.swing.*;   

public class Hello extends JFrame {

    public static void main(String[] args) {
        JOptionPane.showMessageDialog(null, "Hello World!");
        JOptionPane.showMessageDialog(null, "Goodbye");
        System.exit(0);
    }
}


