public class DifferentBalloon extends Balloon {

	public DifferentBalloon(int initialX, int initialY) {
      super();
		x = initialX;
		y = initialY;
		radius = 20;
	}

	// remainder of class

}
