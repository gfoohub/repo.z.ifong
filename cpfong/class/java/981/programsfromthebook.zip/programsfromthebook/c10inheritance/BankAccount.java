public class BankAccount {

    protected int deposit; 

    public BankAccount(int initialDeposit) {
        // remainder of constructor
    }

// remainder of class

}

class BetterAccount extends BankAccount {

    public BetterAccount() {
        deposit = 1000;
    }

// remainder of class

}
