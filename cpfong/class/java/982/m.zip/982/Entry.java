public class Entry{
	private String theName;
	private String theNumber; 

	public void setName   (String n){ theName=n  ; }
	public void setNumber (String n){ theNumber=n; }

	public String getName   (){ return theName  ; }
	public String getNumber (){ return theNumber; }
}
