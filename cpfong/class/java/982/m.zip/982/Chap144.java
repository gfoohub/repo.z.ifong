import java.awt.*;
import java.io.*;

public class Chap144 {
	public static void main(String[] args){
		int in=0;

		System.out.println("input 4x4 number");

		int r,c;
		int m[][]=new int[4][4];

		for (r=0; r<4; r++){
			for (c=0; c<4; c++){
      				BufferedReader br = new BufferedReader(new InputStreamReader(System.in)); 
				try { 
					in = Integer.parseInt(br.readLine()); 
					m[r][c]=in;
				} catch (IOException ioe) { 
				System.out.println("IO error trying to read your name!"); 
				System.exit(1); 
				} 
			}
		}
		System.out.println("after transfer:");
		for (r=0; r<4; r++){
			for (c=0; c<4; c++){
				System.out.print(""+m[c][r]);
			}
			System.out.println("");
		}
		System.exit(0);
	}
}

