public class Card{
	private int rank;
	private String suit;

	public void setRank	(int 	r){ rank=r; }
	public void setSuit	(String s){ suit=s; }

	public int getRank	(){ return rank; }
	public String getSuit	(){ return suit; }
}
