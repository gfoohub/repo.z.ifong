public class WeeklyRain{
	int[] rain = new int[7];
	String rains[]= new String[7];

	rains[0]="10";
}
