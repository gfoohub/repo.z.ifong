public class CardDemo{
	public static void main(String args[]){
		Card[] deck=new Card[52];

		int i,j;
		String[] color={"heart", "diamond", "club", "spade"};
		for (i=0; i<4; i++){
			for (j=0; j<13; j++){
				deck[i*4+j]=new Card();
				deck[i*4+j].setRank(j);
				deck[i*4+j].setSuit(color[i]);
			}
		}
	}
}
