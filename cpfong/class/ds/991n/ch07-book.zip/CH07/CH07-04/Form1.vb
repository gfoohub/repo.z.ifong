Public Class Form1
    Inherits System.Windows.Forms.Form

#Region " Windows Form �]�p�u�㲣�ͪ��{���X "

    Public Sub New()
        MyBase.New()

        '���� Windows Form �]�p�u��һݪ��I�s�C
        InitializeComponent()

        '�b InitializeComponent() �I�s����[�J�Ҧ�����l�]�w

    End Sub

    'Form �мg Dispose �H�M������M��C
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    '�� Windows Form �]�p�u�㪺���n��
    Private components As System.ComponentModel.IContainer

    '�`�N: �H�U�� Windows Form �]�p�u��һݪ��{��
    '�z�i�H�ϥ� Windows Form �]�p�u��i��ק�C
    '�ФŨϥε{���X�s�边�ӭק�o�ǵ{�ǡC
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents source_data_txt As System.Windows.Forms.TextBox
    Friend WithEvents pro_but As System.Windows.Forms.Button
    Friend WithEvents target_data_txt As System.Windows.Forms.TextBox
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents rtbOutput As System.Windows.Forms.RichTextBox
    Friend WithEvents Exit_but As System.Windows.Forms.Button
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.Label1 = New System.Windows.Forms.Label
        Me.source_data_txt = New System.Windows.Forms.TextBox
        Me.pro_but = New System.Windows.Forms.Button
        Me.target_data_txt = New System.Windows.Forms.TextBox
        Me.Label2 = New System.Windows.Forms.Label
        Me.rtbOutput = New System.Windows.Forms.RichTextBox
        Me.Exit_but = New System.Windows.Forms.Button
        Me.SuspendLayout()
        '
        'Label1
        '
        Me.Label1.Location = New System.Drawing.Point(16, 6)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(96, 16)
        Me.Label1.TabIndex = 24
        Me.Label1.Text = "��ǹB�⦡"
        '
        'source_data_txt
        '
        Me.source_data_txt.Location = New System.Drawing.Point(16, 22)
        Me.source_data_txt.Name = "source_data_txt"
        Me.source_data_txt.Size = New System.Drawing.Size(104, 22)
        Me.source_data_txt.TabIndex = 23
        Me.source_data_txt.Text = "1234+*+65/-"
        '
        'pro_but
        '
        Me.pro_but.Location = New System.Drawing.Point(248, 16)
        Me.pro_but.Name = "pro_but"
        Me.pro_but.Size = New System.Drawing.Size(80, 32)
        Me.pro_but.TabIndex = 21
        Me.pro_but.Text = "�ʺA�i��"
        '
        'target_data_txt
        '
        Me.target_data_txt.Location = New System.Drawing.Point(136, 22)
        Me.target_data_txt.Name = "target_data_txt"
        Me.target_data_txt.Size = New System.Drawing.Size(104, 22)
        Me.target_data_txt.TabIndex = 22
        '
        'Label2
        '
        Me.Label2.Location = New System.Drawing.Point(136, 6)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(96, 16)
        Me.Label2.TabIndex = 25
        Me.Label2.Text = "�B�⦡��"
        '
        'rtbOutput
        '
        Me.rtbOutput.Font = New System.Drawing.Font("Courier New", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.rtbOutput.Location = New System.Drawing.Point(16, 54)
        Me.rtbOutput.Name = "rtbOutput"
        Me.rtbOutput.Size = New System.Drawing.Size(224, 296)
        Me.rtbOutput.TabIndex = 32
        Me.rtbOutput.Text = ""
        '
        'Exit_but
        '
        Me.Exit_but.Location = New System.Drawing.Point(256, 318)
        Me.Exit_but.Name = "Exit_but"
        Me.Exit_but.Size = New System.Drawing.Size(72, 24)
        Me.Exit_but.TabIndex = 31
        Me.Exit_but.Text = "����"
        '
        'Form1
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 15)
        Me.ClientSize = New System.Drawing.Size(336, 357)
        Me.Controls.Add(Me.rtbOutput)
        Me.Controls.Add(Me.Exit_but)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.source_data_txt)
        Me.Controls.Add(Me.pro_but)
        Me.Controls.Add(Me.target_data_txt)
        Me.Controls.Add(Me.Label2)
        Me.Name = "Form1"
        Me.Text = "Form1"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

#End Region
    ' =========== Program Description =====================	
    ' �{���W�� : CH07-04				 	           
    ' �t��k�G�ѫ�ǹB�⦡ �p�� �B�⦡����
    ' ��J�G��ǹB�⦡(���פp�󵥩� 20)
    '       �Ҧp: 1234+*+65/-
    ' ��X�G�B���
    '       �Ҧp: 13.8
    ' ======================================================	
    ' �����ܼ�
    Dim max As Integer = 20 ' ������|���̤j�e�q
    Dim n As Integer = 20 ' ��ƶ�������
    Dim SYM_EMPTY As Integer = -1    ' �Ű��|������
    Dim SYM_FULL As Integer = n - 1  ' �����|������
    Dim SYM_TOP As Integer = -1      ' ���|�����б���
    Dim source(20) As Char
    Dim target(20) As Single   ' ���|�}�C

    ' =========== Program Description =====================	
    ' �{���W�� : [����] ���s�� Click �ƥ�{��
    ' =====================================================	
    Private Sub Exit_but_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Exit_but.Click
        Me.Close()
    End Sub

    ' =========== Program Description =====================	
    ' �{���W�� : [�ʺA�i��] ���s CLICK�{��
    ' =====================================================	
    Private Sub pro_but_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles pro_but.Click
        Dim i As Integer

        ' �M�����|�}�C�M������
        For i = 0 To n - 1
            target(i) = 0.0
        Next

        n = source_data_txt.TextLength
        If source_data_txt.TextLength > max Then
            MsgBox("��ƶW�L20�Ӧr�����סA�Э��s��J")
        Else
            ' ���o�r�ꪺ�U�Ӧr��
            For i = 0 To n - 1
                source(i) = source_data_txt.Text.Substring(i, 1)
            Next

            ' -----------------------------------------------------
            ' �I�s�t��k �}�l
            target_data_txt.Text = Expression_Computing()
            ' �I�s�t��k ����
            ' -----------------------------------------------------

        End If
    End Sub

    ' =========== Program Description =====================	
    ' �{���W�� : Expression_Computing    �B�⦡�p��
    ' =====================================================	
    Function Expression_Computing()
        Dim i As Integer
        Dim no1, no2, ret As Single
        Dim ch As Char

        For i = 0 To n - 1
            ch = source(i)
            MsgBox("�B�@ step # " & i & " ==>" & ch)

            ' �O�_�O�B��l
            If (Not isOperand(ch)) Then
                ' �O�B�⤸ ==> �r�����⬰�ƭȡA��J���|
                push(Asc(ch) - 48)
            Else
                ' ���O�B�⤸(�O�B��l) ==> ���X2�ӼƦr�@�p��
                no1 = pop()
                no2 = pop()
                ret = Operation(ch, no1, no2)
                ' �p�⵲�G�A��J���|
                push(ret)
            End If
        Next

        MsgBox("�p�⵲��")
        Return pop()
    End Function

    ' =========== Program Description =====================	
    ' �{���W�� : Operation      �p�⦡
    ' =====================================================	
    Function Operation(ByVal op As Char, ByVal ch1 As Single, ByVal ch2 As Single) As Single
        Select Case op
            Case "+"
                MsgBox("�p���==> " & ch2 & " + " & ch1 & " = " & ch2 + ch1)
                Return ch2 + ch1
            Case "-"
                MsgBox("�p���==> " & ch2 & " - " & ch1 & " = " & ch2 - ch1)
                Return ch2 - ch1
            Case "*"
                MsgBox("�p���==> " & ch2 & " * " & ch1 & " = " & ch2 * ch1)
                Return ch2 * ch1
            Case "/"
                MsgBox("�p���==> " & ch2 & " / " & ch1 & " = " & ch2 / ch1)
                Return ch2 / ch1
            Case Else
                Return 0
        End Select
    End Function

    ' =========== Program Description =====================	
    ' �禡�W�� : isOperand      �P�_�O�_�O�B��l
    ' =====================================================	
    Function isOperand(ByVal ch As Char) As Boolean
        Dim ret As Boolean
        Select Case ch
            Case "+", "-", "*", "/", "(", ")"
                ret = True
            Case Else
                ret = False
        End Select
        Return ret
    End Function

    ' =========== Program Description =====================	
    ' �禡�W�� : pop      �Ѱ��|���X���
    ' =====================================================	
    Function pop() As Single
        Dim exp As Single
        ' POP �u�X���
        exp = target(SYM_TOP)
        MsgBox("POP �u�X�B��l==> " & exp)

        SYM_TOP -= 1
        travel()
        Return exp

    End Function

    ' =========== Program Description =====================	
    ' �禡�W�� : push      �N��Ʃ�J���|
    ' =====================================================	
    Function push(ByVal exp)
        ' PUSH ��J���
        MsgBox("PUSH ��J�B��l==> " & exp)
        SYM_TOP += 1
        target(SYM_TOP) = exp
        travel()
    End Function


    ' =========== Program Description =====================	
    ' �{���W�� : travel      ��X���|���
    ' =====================================================	
    Sub travel()
        Dim i As Integer
        rtbOutput.AppendText("stack data : ")
        For i = 0 To SYM_TOP
            rtbOutput.AppendText(target(i) & "  ")
        Next
        rtbOutput.AppendText(Chr(13))
    End Sub

End Class
