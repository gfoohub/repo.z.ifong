Public Class Form1
    Inherits System.Windows.Forms.Form

#Region " Windows Form �]�p�u�㲣�ͪ��{���X "

    Public Sub New()
        MyBase.New()

        '���� Windows Form �]�p�u��һݪ��I�s�C
        InitializeComponent()

        '�b InitializeComponent() �I�s����[�J�Ҧ�����l�]�w

    End Sub

    'Form �мg Dispose �H�M������M��C
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    '�� Windows Form �]�p�u�㪺���n��
    Private components As System.ComponentModel.IContainer

    '�`�N: �H�U�� Windows Form �]�p�u��һݪ��{��
    '�z�i�H�ϥ� Windows Form �]�p�u��i��ק�C
    '�ФŨϥε{���X�s�边�ӭק�o�ǵ{�ǡC
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents source_data_txt As System.Windows.Forms.TextBox
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents pro_but As System.Windows.Forms.Button
    Friend WithEvents target_data_txt As System.Windows.Forms.TextBox
    Friend WithEvents rtbOutput As System.Windows.Forms.RichTextBox
    Friend WithEvents Exit_but As System.Windows.Forms.Button
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.pro_but = New System.Windows.Forms.Button
        Me.source_data_txt = New System.Windows.Forms.TextBox
        Me.Label1 = New System.Windows.Forms.Label
        Me.target_data_txt = New System.Windows.Forms.TextBox
        Me.Label2 = New System.Windows.Forms.Label
        Me.Label3 = New System.Windows.Forms.Label
        Me.Label4 = New System.Windows.Forms.Label
        Me.Label5 = New System.Windows.Forms.Label
        Me.Label6 = New System.Windows.Forms.Label
        Me.Label7 = New System.Windows.Forms.Label
        Me.rtbOutput = New System.Windows.Forms.RichTextBox
        Me.Exit_but = New System.Windows.Forms.Button
        Me.SuspendLayout()
        '
        'pro_but
        '
        Me.pro_but.Location = New System.Drawing.Point(16, 120)
        Me.pro_but.Name = "pro_but"
        Me.pro_but.Size = New System.Drawing.Size(72, 24)
        Me.pro_but.TabIndex = 0
        Me.pro_but.Text = "���|�ާ@"
        '
        'source_data_txt
        '
        Me.source_data_txt.Location = New System.Drawing.Point(16, 80)
        Me.source_data_txt.Name = "source_data_txt"
        Me.source_data_txt.Size = New System.Drawing.Size(176, 22)
        Me.source_data_txt.TabIndex = 1
        Me.source_data_txt.Text = "I@LOVE@PROGRAMS."
        '
        'Label1
        '
        Me.Label1.Location = New System.Drawing.Point(16, 64)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(96, 16)
        Me.Label1.TabIndex = 2
        Me.Label1.Text = "��J(source)"
        '
        'target_data_txt
        '
        Me.target_data_txt.Location = New System.Drawing.Point(248, 80)
        Me.target_data_txt.Name = "target_data_txt"
        Me.target_data_txt.Size = New System.Drawing.Size(176, 22)
        Me.target_data_txt.TabIndex = 1
        '
        'Label2
        '
        Me.Label2.Location = New System.Drawing.Point(248, 64)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(96, 16)
        Me.Label2.TabIndex = 2
        Me.Label2.Text = "��X(target)"
        '
        'Label3
        '
        Me.Label3.Location = New System.Drawing.Point(16, 8)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(96, 16)
        Me.Label3.TabIndex = 2
        Me.Label3.Text = "��h:"
        '
        'Label4
        '
        Me.Label4.Location = New System.Drawing.Point(24, 24)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(160, 16)
        Me.Label4.TabIndex = 2
        Me.Label4.Text = "1.�r���̧ǩ�J���|"
        '
        'Label5
        '
        Me.Label5.Location = New System.Drawing.Point(248, 24)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(136, 16)
        Me.Label5.TabIndex = 2
        Me.Label5.Text = "2.�J��""@""�Ÿ��ߧY�u�X"
        '
        'Label6
        '
        Me.Label6.Location = New System.Drawing.Point(24, 40)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(216, 16)
        Me.Label6.TabIndex = 2
        Me.Label6.Text = "3.��J���r���̤W��r���j�ɡA�u�X"
        '
        'Label7
        '
        Me.Label7.Location = New System.Drawing.Point(248, 40)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(136, 16)
        Me.Label7.TabIndex = 2
        Me.Label7.Text = "4.�Ѿl�̨̧Ǽu�X"
        '
        'rtbOutput
        '
        Me.rtbOutput.Font = New System.Drawing.Font("Courier New", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.rtbOutput.Location = New System.Drawing.Point(100, 112)
        Me.rtbOutput.Name = "rtbOutput"
        Me.rtbOutput.Size = New System.Drawing.Size(404, 128)
        Me.rtbOutput.TabIndex = 26
        Me.rtbOutput.Text = ""
        '
        'Exit_but
        '
        Me.Exit_but.Location = New System.Drawing.Point(16, 212)
        Me.Exit_but.Name = "Exit_but"
        Me.Exit_but.Size = New System.Drawing.Size(72, 24)
        Me.Exit_but.TabIndex = 25
        Me.Exit_but.Text = "����"
        '
        'Form1
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 15)
        Me.ClientSize = New System.Drawing.Size(512, 245)
        Me.Controls.Add(Me.rtbOutput)
        Me.Controls.Add(Me.Exit_but)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.source_data_txt)
        Me.Controls.Add(Me.pro_but)
        Me.Controls.Add(Me.target_data_txt)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.Label6)
        Me.Controls.Add(Me.Label7)
        Me.Name = "Form1"
        Me.Text = "Form1"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

#End Region
    ' =========== Program Description =====================	
    ' �{���W�� : CH07-01	[�򥻽d��]			 	           
    ' �t��k�G���|��PUSH,POP�ʧ@
    ' ��J�G�r��A���פp�󵥩� 20
    ' ��X�G�̳W�h�ާ@���|�B�@�ұo�쪺�r��
    ' �W�h�G1.�r���̧ǩ�J���|
    '       2.�J��"@"�Ÿ��ߧY�u�X
    '       3.��J���r���̤W��r���j�ɡA�u�X
    '       4.�Ѿl�̨̧Ǽu�X
    ' ======================================================	
    ' �����ܼ�
    Dim max As Integer = 20   ' ������|���̤j�e�q
    Dim target_top As Integer = -1 ' ���|�����б���
    Dim target_stack(20) As Char  ' ���|����ư}�C

    ' =========== Program Description =====================	
    ' �{���W�� : [����]���s��Click�ƥ�{��
    ' =====================================================	
    Private Sub Exit_but_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Exit_but.Click
        Me.Close()
    End Sub

    ' =========== Program Description =====================	
    ' �{���W�� : [���|�ާ@]���s��Click�ƥ�{��
    ' =====================================================	
    Private Sub pro_but_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles pro_but.Click
        Dim i As Integer
        Dim keychar As Char
        target_top = -1
        For i = 0 To 20
            target_stack(i) = ""
        Next

        If source_data_txt.TextLength > max Then
            MsgBox("��ƶW�L20�Ӧr�����סA�Э��s��J")
        Else
            ' �q�r�ꤤ�̧Ǩ��X�r��
            For i = 1 To source_data_txt.TextLength
                keychar = source_data_txt.Text.Substring(i - 1, 1)
                If target_top >= max Then
                    MsgBox("���|�w��")
                Else
                    ' PUSH ��J���
                    MsgBox("PUSH ��J���=> " & keychar)
                    target_top += 1
                    target_stack(target_top) = keychar
                    travel()

                    ' �ˬd�O�_�ŦX�W�h�A��POP �u�X���
                    If target_top >= 1 Then
                        If keychar = "@" Or target_stack(target_top) >= target_stack(target_top - 1) Then
                            MsgBox("POP �u�X���=> " & target_stack(target_top))
                            target_data_txt.Text = target_stack(target_top) & target_data_txt.Text
                            target_top -= 1
                            travel()
                        End If
                    End If
                End If
            Next

            ' �̫���|������ơA�̧Ǽu�X
            If target_top >= 0 Then
                MsgBox("POP  �}�l�̧Ǽu�X���|�������")
                For i = target_top To 0 Step -1
                    MsgBox("POP �u�X���=> " & target_stack(i))
                    target_data_txt.Text = target_stack(i) & target_data_txt.Text
                    target_stack(i) = ""
                    travel()
                Next
            End If
        End If
    End Sub

    ' =========== Program Description =====================	
    ' �{���W�� : travel      ��X���|���
    ' =====================================================	
    Sub travel()
        Dim i As Integer
        rtbOutput.AppendText("stack data : ")
        For i = 0 To target_top
            rtbOutput.AppendText(target_stack(i) & "  ")
        Next
        rtbOutput.AppendText(Chr(13))
    End Sub

End Class
