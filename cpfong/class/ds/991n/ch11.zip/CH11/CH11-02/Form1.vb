Public Class Form1
    Inherits System.Windows.Forms.Form

#Region " Windows Form �]�p�u�㲣�ͪ��{���X "

    Public Sub New()
        MyBase.New()

        '���� Windows Form �]�p�u��һݪ��I�s�C
        InitializeComponent()

        '�b InitializeComponent() �I�s����[�J�Ҧ�����l�]�w

    End Sub

    'Form �мg Dispose �H�M������M��C
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    '�� Windows Form �]�p�u�㪺���n��
    Private components As System.ComponentModel.IContainer

    '�`�N: �H�U�� Windows Form �]�p�u��һݪ��{��
    '�z�i�H�ϥ� Windows Form �]�p�u��i��ק�C
    '�ФŨϥε{���X�s�边�ӭק�o�ǵ{�ǡC
    Friend WithEvents GroupBox1 As System.Windows.Forms.GroupBox
    Friend WithEvents auto_rad As System.Windows.Forms.RadioButton
    Friend WithEvents step_rad As System.Windows.Forms.RadioButton
    Friend WithEvents tree_but As System.Windows.Forms.Button
    Friend WithEvents create_but As System.Windows.Forms.Button
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox
        Me.auto_rad = New System.Windows.Forms.RadioButton
        Me.step_rad = New System.Windows.Forms.RadioButton
        Me.tree_but = New System.Windows.Forms.Button
        Me.create_but = New System.Windows.Forms.Button
        Me.Label1 = New System.Windows.Forms.Label
        Me.Label2 = New System.Windows.Forms.Label
        Me.GroupBox1.SuspendLayout()
        Me.SuspendLayout()
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.auto_rad)
        Me.GroupBox1.Controls.Add(Me.step_rad)
        Me.GroupBox1.Location = New System.Drawing.Point(448, 24)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(144, 40)
        Me.GroupBox1.TabIndex = 39
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "�ާ@�覡"
        '
        'auto_rad
        '
        Me.auto_rad.Location = New System.Drawing.Point(8, 16)
        Me.auto_rad.Name = "auto_rad"
        Me.auto_rad.Size = New System.Drawing.Size(64, 20)
        Me.auto_rad.TabIndex = 0
        Me.auto_rad.Text = "�۰�"
        '
        'step_rad
        '
        Me.step_rad.Checked = True
        Me.step_rad.Location = New System.Drawing.Point(72, 16)
        Me.step_rad.Name = "step_rad"
        Me.step_rad.Size = New System.Drawing.Size(64, 20)
        Me.step_rad.TabIndex = 0
        Me.step_rad.TabStop = True
        Me.step_rad.Text = "���"
        '
        'tree_but
        '
        Me.tree_but.Location = New System.Drawing.Point(608, 8)
        Me.tree_but.Name = "tree_but"
        Me.tree_but.Size = New System.Drawing.Size(104, 32)
        Me.tree_but.TabIndex = 38
        Me.tree_but.Text = "�}�C�ƦC�𵲺c"
        '
        'create_but
        '
        Me.create_but.Location = New System.Drawing.Point(608, 48)
        Me.create_but.Name = "create_but"
        Me.create_but.Size = New System.Drawing.Size(104, 32)
        Me.create_but.TabIndex = 37
        Me.create_but.Text = "�إߤG����}�C"
        '
        'Label1
        '
        Me.Label1.Location = New System.Drawing.Point(8, 40)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(32, 16)
        Me.Label1.TabIndex = 40
        Me.Label1.Text = "���"
        '
        'Label2
        '
        Me.Label2.Location = New System.Drawing.Point(8, 80)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(32, 16)
        Me.Label2.TabIndex = 40
        Me.Label2.Text = "�}�C"
        '
        'Form1
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 15)
        Me.ClientSize = New System.Drawing.Size(720, 453)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.GroupBox1)
        Me.Controls.Add(Me.tree_but)
        Me.Controls.Add(Me.create_but)
        Me.Controls.Add(Me.Label2)
        Me.Name = "Form1"
        Me.Text = "Form1"
        Me.GroupBox1.ResumeLayout(False)
        Me.ResumeLayout(False)

    End Sub

#End Region
    ' =========== Program Description ============================
    ' �{���W�� : CH11-02	
    ' �t��k�G�Q�ΤG���}�C�إߧ���G����
    ' ��J�G��ư}�C���
    ' ��X�G�ʺA�i�ܸ��|����M�A�B�i�ܧ���G����
    ' ============================================================

    ' �ŧi�����ܼ�
    Dim n As Integer = 9               ' �}�C�̤j�ƶq
    Dim ValueSize As Integer = 9       ' ��Ƴ̤j�ƶq
    Dim Tree(9, 9) As Integer ' �𪺰}�C���
    Dim A() As Integer = {5, 3, 7, 2, 9, 4, 6, 8, 1}  ' ��ƶ�

    Dim value_txt(9) As TextBox  ' �ʺA�i�ܤ�TextBox����}�C
    Dim value_lab(9) As Label    ' �ʺA�i�ܤ�Label����}�C

    Dim array_txt(9, 9) As TextBox  ' �ʺA�i�ܤ�TextBox����}�C
    Dim array_col_lab(9) As Label   ' �ʺA�i�ܤ�Label����}�C
    Dim array_row_lab(9) As Label   ' �ʺA�i�ܤ�Label����}�C

    Dim tree_txt(9, 9) As TextBox  ' �ʺA�i�ܤ�TextBox����}�C
    Dim tree_lab(9, 9) As Label    ' �ʺA�i�ܤ�Label����}�C

    Dim PauseTime, Start, Finish, TotalTime As Single
    Dim shiftx, shifty, gapx, gapy As Integer
    Dim shiftx1, shifty1, gapx1, gapy1 As Integer

    ' =========== Program Description ============================
    ' �{���W�� : create_bintree2  �Q�ΤG���}�C��ƨӲ��ͧ���G����
    ' ============================================================
    Sub create_bintree2(ByVal A, ByVal m)
        Dim i, j, k, h, l As Integer

        ' �t��k�}�l
        ' ---------------------------------------------------------
        For i = 0 To m - 1 '���J���C����ƳB�z

            ' �ʺA�i��
            ' --------
            ' �C��:�L�Ŧ�
            value_txt(i).BackColor = System.Drawing.Color.FromArgb(CType(128, Byte), CType(255, Byte), CType(255, Byte))
            ' --------

            j = 1
            k = 1
            For h = 0 To ValueSize - 1 ' �Ѿ𪺰��רӳB�z 
                j = h + 1

                ' �ʺA�i��
                ' --------
                ' �C��:�L�Ŧ�
                tree_txt(j, k).BackColor = System.Drawing.Color.FromArgb(CType(128, Byte), CType(255, Byte), CType(255, Byte))
                ' ��border���ܤƳгy�ʪ��ĪG
                For l = 1 To 4
                    tree_txt(j, k).BorderStyle = System.Windows.Forms.BorderStyle.None
                    tree_txt(j, k).BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
                    tree_txt(j, k).BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
                Next
                If auto_rad.Checked Then
                    ' �Ȱ��ɶ�����
                    PauseTime = 1                ' �]�w�Ȱ��ɶ�
                    Start = DateAndTime.Timer    ' �]�w�}�l�Ȱ����ɨ�
                    Do While DateAndTime.Timer < Start + PauseTime
                        Application.DoEvents()   ' �N�{�������v�����䥦�{��
                    Loop
                Else
                    MsgBox("�ثe�ˬd�`�I:" & "<" & j & "," & k & ">")
                End If
                ' ---------

                If (Tree(j, k) = -1) Then
                    ' �p�G�O�Ÿ`�I�N���Ʃ�i�h 
                    Tree(j, k) = A(i)

                    ' �ʺA�i��
                    ' --------
                    ' �C��:�L����
                    array_txt(j, k).Text = A(i)
                    tree_txt(j, k).Text = A(i)
                    tree_txt(j, k).BackColor = System.Drawing.Color.FromArgb(CType(255, Byte), CType(128, Byte), CType(128, Byte))
                    If auto_rad.Checked Then
                        ' �Ȱ��ɶ�����
                        PauseTime = 1                ' �]�w�Ȱ��ɶ�
                        Start = DateAndTime.Timer    ' �]�w�}�l�Ȱ����ɨ�
                        Do While DateAndTime.Timer < Start + PauseTime
                            Application.DoEvents()   ' �N�{�������v�����䥦�{��
                        Loop
                    Else
                        MsgBox("�ثe�ˬd�`�I:" & "<" & j & "," & k & ">")
                    End If
                    ' ---------

                    Exit For
                ElseIf (Tree(j, k) < A(i)) Then
                    ' �p�G���`�I����Ȥ���p,���k�䨫 
                    k = 2 * k
                Else
                    ' �_�h,�����䨫 
                    k = 2 * k - 1
                End If
            Next
        Next
        ' �t��k����
        ' ---------------------------------------------------------
    End Sub

    ' =========== Program Description ============================
    ' �{���W�� : �{���Ұʬɭ�
    ' ============================================================
    Private Sub Form1_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Dim i, j As Integer

        For i = 1 To ValueSize
            For j = 1 To ValueSize
                Tree(i, j) = -1
            Next
        Next

        ' �ʺA�i��
        ' ---------
        shiftx = 40 : shifty = 40 : gapx = 20 : gapy = 20
        ' �إ߸�ƪ���}�C
        For i = 0 To ValueSize - 1
            value_txt(i) = New TextBox
            value_txt(i).Multiline = True
            value_txt(i).Width = 20
            value_txt(i).Height = 20
            value_txt(i).Left = shiftx + i * gapx
            value_txt(i).Top = shifty
            value_txt(i).Font = New System.Drawing.Font( _
               "�s�ө���", 9.0!, System.Drawing.FontStyle.Regular, _
               System.Drawing.GraphicsUnit.Point, CType(136, Byte))
            value_txt(i).Text = A(i)
            value_txt(i).TextAlign = HorizontalAlignment.Center

            value_lab(i) = New Label
            value_lab(i).Width = 10
            value_lab(i).Height = 20
            value_lab(i).Left = shiftx + i * gapx + 5
            value_lab(i).Top = shifty - gapy + 5
            value_lab(i).Font = New System.Drawing.Font( _
               "�s�ө���", 9.0!, System.Drawing.FontStyle.Regular, _
               System.Drawing.GraphicsUnit.Point, CType(136, Byte))
            value_lab(i).Text = i

            Me.Controls.Add(value_txt(i))
            Me.Controls.Add(value_lab(i))
        Next

        ' �إ� array ����}�C
        For i = 1 To ValueSize
            For j = 1 To ValueSize
                array_txt(i, j) = New TextBox
                array_txt(i, j).Multiline = True
                array_txt(i, j).Width = 20
                array_txt(i, j).Height = 20
                array_txt(i, j).Left = shiftx + j * gapx
                array_txt(i, j).Top = shifty + (i + 1) * gapy
                array_txt(i, j).Font = New System.Drawing.Font( _
                   "�s�ө���", 9.0!, System.Drawing.FontStyle.Regular, _
                   System.Drawing.GraphicsUnit.Point, CType(136, Byte))
                array_txt(i, j).Text = ""
                array_txt(i, j).TextAlign = HorizontalAlignment.Center

                Me.Controls.Add(array_txt(i, j))
            Next
        Next
        For i = 1 To ValueSize
            array_col_lab(i) = New Label
            array_col_lab(i).Width = 16
            array_col_lab(i).Height = 20
            array_col_lab(i).Left = shiftx + i * gapx + 5
            array_col_lab(i).Top = shifty + 20 + 5
            array_col_lab(i).Font = New System.Drawing.Font( _
               "�s�ө���", 9.0!, System.Drawing.FontStyle.Regular, _
               System.Drawing.GraphicsUnit.Point, CType(136, Byte))
            array_col_lab(i).Text = i

            array_row_lab(i) = New Label
            array_row_lab(i).Width = 16
            array_row_lab(i).Height = 20
            array_row_lab(i).Left = shiftx + 5
            array_row_lab(i).Top = shifty + (i + 1) * gapy + 5
            array_row_lab(i).Font = New System.Drawing.Font( _
               "�s�ө���", 9.0!, System.Drawing.FontStyle.Regular, _
               System.Drawing.GraphicsUnit.Point, CType(136, Byte))
            array_row_lab(i).Text = i

            Me.Controls.Add(array_col_lab(i))
            Me.Controls.Add(array_row_lab(i))
        Next

        ' �إ� tree ����}�C
        For i = 1 To ValueSize
            For j = 1 To ValueSize
                tree_txt(i, j) = New TextBox
                tree_txt(i, j).Multiline = True
                tree_txt(i, j).Width = 20
                tree_txt(i, j).Height = 20
                tree_txt(i, j).Left = shiftx
                tree_txt(i, j).Top = shifty
                tree_txt(i, j).Font = New System.Drawing.Font( _
                   "�s�ө���", 9.0!, System.Drawing.FontStyle.Regular, _
                   System.Drawing.GraphicsUnit.Point, CType(136, Byte))
                tree_txt(i, j).Text = ""
                tree_txt(i, j).TextAlign = HorizontalAlignment.Center
                tree_txt(i, j).Visible = False

                tree_lab(i, j) = New Label
                tree_lab(i, j).Width = 40
                tree_lab(i, j).Height = 20
                tree_lab(i, j).Left = shiftx
                tree_lab(i, j).Top = shifty
                tree_lab(i, j).Font = New System.Drawing.Font( _
                   "�s�ө���", 9.0!, System.Drawing.FontStyle.Regular, _
                   System.Drawing.GraphicsUnit.Point, CType(136, Byte))
                tree_lab(i, j).Text = "<" & i & "-" & j & ">"
                tree_lab(i, j).Visible = False

                Me.Controls.Add(tree_txt(i, j))
                Me.Controls.Add(tree_lab(i, j))
            Next
        Next
        ' ---------
    End Sub

    ' =========== Program Description ============================
    ' �{���W�� : [�إߤG����}�C]���s�� Click �ƥ�
    ' ============================================================
    Private Sub create_but_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles create_but.Click
        create_but.Enabled = False
        create_bintree2(A, ValueSize)
    End Sub

    ' =========== Program Description ============================
    ' �{���W�� : [�}�C�ƦC�𵲺c]���s�� Click �ƥ�
    ' ============================================================
    Private Sub tree_but_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles tree_but.Click
        Call proAssignTree()
    End Sub

    ' =========== Program Description ==============================
    ' �{���W�� : proAssignTree  ��tree�y�Ц�m�A����left,top���𵲺c
    ' ==============================================================
    Sub proAssignTree()
        Dim i, j As Integer
        Dim row_pos, col_pos As Integer

        shiftx1 = shiftx : shifty1 = shifty + 250 : gapx1 = gapx * 2 : gapy1 = gapy * 2
        ' �̧ǲ���tree���󪺦�m
        For i = 1 To 4
            For j = 1 To 2 ^ (i - 1)
                row_pos = i - 1
                col_pos = j - 1

                ' ��m�s��   row=0                               8
                '            row=1               4                               12
                '            row=2       2               6              10               14            
                '            row=3   1       3       5       7       9       11      13     15
                tree_txt(i, j).Visible = True
                tree_txt(i, j).Left = shiftx1 + 2 ^ (3 - row_pos) * gapx1 + 2 ^ (4 - row_pos) * col_pos * gapx1
                tree_txt(i, j).Top = shifty1 + row_pos * gapy1
                tree_lab(i, j).Visible = True
                tree_lab(i, j).Left = tree_txt(i, j).Left - 40
                tree_lab(i, j).Top = tree_txt(i, j).Top
            Next
        Next
    End Sub
End Class
