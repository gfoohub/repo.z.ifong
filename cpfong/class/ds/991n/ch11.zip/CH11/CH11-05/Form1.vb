Public Class Form1
    Inherits System.Windows.Forms.Form

#Region " Windows Form �]�p�u�㲣�ͪ��{���X "

    Public Sub New()
        MyBase.New()

        '���� Windows Form �]�p�u��һݪ��I�s�C
        InitializeComponent()

        '�b InitializeComponent() �I�s����[�J�Ҧ�����l�]�w

    End Sub

    'Form �мg Dispose �H�M������M��C
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    '�� Windows Form �]�p�u�㪺���n��
    Private components As System.ComponentModel.IContainer

    '�`�N: �H�U�� Windows Form �]�p�u��һݪ��{��
    '�z�i�H�ϥ� Windows Form �]�p�u��i��ק�C
    '�ФŨϥε{���X�s�边�ӭק�o�ǵ{�ǡC
    Friend WithEvents tree_but As System.Windows.Forms.Button
    Friend WithEvents create_but As System.Windows.Forms.Button
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents GroupBox1 As System.Windows.Forms.GroupBox
    Friend WithEvents auto_rad As System.Windows.Forms.RadioButton
    Friend WithEvents step_rad As System.Windows.Forms.RadioButton
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents preorder_but As System.Windows.Forms.Button
    Friend WithEvents preorder_txt As System.Windows.Forms.TextBox
    Friend WithEvents inorder_but As System.Windows.Forms.Button
    Friend WithEvents postorder_but As System.Windows.Forms.Button
    Friend WithEvents levelorder_but As System.Windows.Forms.Button
    Friend WithEvents inorder_txt As System.Windows.Forms.TextBox
    Friend WithEvents postorder_txt As System.Windows.Forms.TextBox
    Friend WithEvents levelorder_txt As System.Windows.Forms.TextBox
    Friend WithEvents now_rad As System.Windows.Forms.RadioButton
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.tree_but = New System.Windows.Forms.Button
        Me.create_but = New System.Windows.Forms.Button
        Me.Label6 = New System.Windows.Forms.Label
        Me.Label3 = New System.Windows.Forms.Label
        Me.Label4 = New System.Windows.Forms.Label
        Me.Label5 = New System.Windows.Forms.Label
        Me.GroupBox1 = New System.Windows.Forms.GroupBox
        Me.auto_rad = New System.Windows.Forms.RadioButton
        Me.step_rad = New System.Windows.Forms.RadioButton
        Me.Label2 = New System.Windows.Forms.Label
        Me.preorder_but = New System.Windows.Forms.Button
        Me.preorder_txt = New System.Windows.Forms.TextBox
        Me.Label7 = New System.Windows.Forms.Label
        Me.inorder_but = New System.Windows.Forms.Button
        Me.postorder_but = New System.Windows.Forms.Button
        Me.levelorder_but = New System.Windows.Forms.Button
        Me.inorder_txt = New System.Windows.Forms.TextBox
        Me.postorder_txt = New System.Windows.Forms.TextBox
        Me.levelorder_txt = New System.Windows.Forms.TextBox
        Me.now_rad = New System.Windows.Forms.RadioButton
        Me.GroupBox1.SuspendLayout()
        Me.SuspendLayout()
        '
        'tree_but
        '
        Me.tree_but.Location = New System.Drawing.Point(608, 8)
        Me.tree_but.Name = "tree_but"
        Me.tree_but.Size = New System.Drawing.Size(104, 32)
        Me.tree_but.TabIndex = 58
        Me.tree_but.Text = "�}�C�ƦC�𵲺c"
        '
        'create_but
        '
        Me.create_but.Location = New System.Drawing.Point(608, 48)
        Me.create_but.Name = "create_but"
        Me.create_but.Size = New System.Drawing.Size(104, 32)
        Me.create_but.TabIndex = 57
        Me.create_but.Text = "�إߤG����}�C"
        '
        'Label6
        '
        Me.Label6.Location = New System.Drawing.Point(0, 40)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(32, 16)
        Me.Label6.TabIndex = 68
        Me.Label6.Text = "Value"
        '
        'Label3
        '
        Me.Label3.Location = New System.Drawing.Point(0, 104)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(32, 16)
        Me.Label3.TabIndex = 66
        Me.Label3.Text = "Data"
        '
        'Label4
        '
        Me.Label4.Location = New System.Drawing.Point(0, 120)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(32, 16)
        Me.Label4.TabIndex = 63
        Me.Label4.Text = "Right"
        '
        'Label5
        '
        Me.Label5.Location = New System.Drawing.Point(0, 144)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(40, 16)
        Me.Label5.TabIndex = 64
        Me.Label5.Text = "Parent"
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.now_rad)
        Me.GroupBox1.Controls.Add(Me.auto_rad)
        Me.GroupBox1.Controls.Add(Me.step_rad)
        Me.GroupBox1.Location = New System.Drawing.Point(368, 24)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(224, 48)
        Me.GroupBox1.TabIndex = 59
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "�ާ@�覡"
        '
        'auto_rad
        '
        Me.auto_rad.Location = New System.Drawing.Point(8, 16)
        Me.auto_rad.Name = "auto_rad"
        Me.auto_rad.Size = New System.Drawing.Size(64, 20)
        Me.auto_rad.TabIndex = 0
        Me.auto_rad.Text = "�۰�"
        '
        'step_rad
        '
        Me.step_rad.Location = New System.Drawing.Point(72, 16)
        Me.step_rad.Name = "step_rad"
        Me.step_rad.Size = New System.Drawing.Size(64, 20)
        Me.step_rad.TabIndex = 0
        Me.step_rad.Text = "���"
        '
        'Label2
        '
        Me.Label2.Location = New System.Drawing.Point(0, 88)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(32, 16)
        Me.Label2.TabIndex = 65
        Me.Label2.Text = "Left"
        '
        'preorder_but
        '
        Me.preorder_but.Enabled = False
        Me.preorder_but.Location = New System.Drawing.Point(8, 347)
        Me.preorder_but.Name = "preorder_but"
        Me.preorder_but.Size = New System.Drawing.Size(104, 24)
        Me.preorder_but.TabIndex = 62
        Me.preorder_but.Text = "�e�Ƿj�M�k"
        '
        'preorder_txt
        '
        Me.preorder_txt.BackColor = System.Drawing.Color.FromArgb(CType(255, Byte), CType(255, Byte), CType(128, Byte))
        Me.preorder_txt.Location = New System.Drawing.Point(128, 347)
        Me.preorder_txt.Name = "preorder_txt"
        Me.preorder_txt.Size = New System.Drawing.Size(272, 22)
        Me.preorder_txt.TabIndex = 60
        Me.preorder_txt.Text = ""
        '
        'Label7
        '
        Me.Label7.Location = New System.Drawing.Point(0, 184)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(32, 16)
        Me.Label7.TabIndex = 67
        Me.Label7.Text = "Tree"
        '
        'inorder_but
        '
        Me.inorder_but.Enabled = False
        Me.inorder_but.Location = New System.Drawing.Point(8, 379)
        Me.inorder_but.Name = "inorder_but"
        Me.inorder_but.Size = New System.Drawing.Size(104, 24)
        Me.inorder_but.TabIndex = 69
        Me.inorder_but.Text = "���Ƿj�M�k"
        '
        'postorder_but
        '
        Me.postorder_but.Enabled = False
        Me.postorder_but.Location = New System.Drawing.Point(8, 411)
        Me.postorder_but.Name = "postorder_but"
        Me.postorder_but.Size = New System.Drawing.Size(104, 24)
        Me.postorder_but.TabIndex = 70
        Me.postorder_but.Text = "��Ƿj�M�k"
        '
        'levelorder_but
        '
        Me.levelorder_but.Enabled = False
        Me.levelorder_but.Location = New System.Drawing.Point(8, 443)
        Me.levelorder_but.Name = "levelorder_but"
        Me.levelorder_but.Size = New System.Drawing.Size(104, 24)
        Me.levelorder_but.TabIndex = 71
        Me.levelorder_but.Text = "���h�j�M�k"
        '
        'inorder_txt
        '
        Me.inorder_txt.BackColor = System.Drawing.Color.FromArgb(CType(255, Byte), CType(255, Byte), CType(128, Byte))
        Me.inorder_txt.Location = New System.Drawing.Point(128, 379)
        Me.inorder_txt.Name = "inorder_txt"
        Me.inorder_txt.Size = New System.Drawing.Size(272, 22)
        Me.inorder_txt.TabIndex = 60
        Me.inorder_txt.Text = ""
        '
        'postorder_txt
        '
        Me.postorder_txt.BackColor = System.Drawing.Color.FromArgb(CType(255, Byte), CType(255, Byte), CType(128, Byte))
        Me.postorder_txt.Location = New System.Drawing.Point(128, 411)
        Me.postorder_txt.Name = "postorder_txt"
        Me.postorder_txt.Size = New System.Drawing.Size(272, 22)
        Me.postorder_txt.TabIndex = 60
        Me.postorder_txt.Text = ""
        '
        'levelorder_txt
        '
        Me.levelorder_txt.BackColor = System.Drawing.Color.FromArgb(CType(255, Byte), CType(255, Byte), CType(128, Byte))
        Me.levelorder_txt.Location = New System.Drawing.Point(128, 443)
        Me.levelorder_txt.Name = "levelorder_txt"
        Me.levelorder_txt.Size = New System.Drawing.Size(272, 22)
        Me.levelorder_txt.TabIndex = 60
        Me.levelorder_txt.Text = ""
        '
        'now_rad
        '
        Me.now_rad.Checked = True
        Me.now_rad.Location = New System.Drawing.Point(136, 16)
        Me.now_rad.Name = "now_rad"
        Me.now_rad.Size = New System.Drawing.Size(72, 20)
        Me.now_rad.TabIndex = 1
        Me.now_rad.TabStop = True
        Me.now_rad.Text = "�ߧY���"
        '
        'Form1
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 15)
        Me.ClientSize = New System.Drawing.Size(720, 477)
        Me.Controls.Add(Me.levelorder_but)
        Me.Controls.Add(Me.postorder_but)
        Me.Controls.Add(Me.inorder_but)
        Me.Controls.Add(Me.tree_but)
        Me.Controls.Add(Me.create_but)
        Me.Controls.Add(Me.Label6)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.GroupBox1)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.preorder_but)
        Me.Controls.Add(Me.preorder_txt)
        Me.Controls.Add(Me.Label7)
        Me.Controls.Add(Me.inorder_txt)
        Me.Controls.Add(Me.postorder_txt)
        Me.Controls.Add(Me.levelorder_txt)
        Me.Name = "Form1"
        Me.Text = "Form1"
        Me.GroupBox1.ResumeLayout(False)
        Me.ResumeLayout(False)

    End Sub

#End Region
    ' =========== Program Description ============================
    ' �{���W�� : CH11-05	
    ' �t��k�G�Q���쵲��C�إߤG����A�B�ΦU�ؤ�k���X
    ' ��J�G��ư}�C���
    ' ��X�G�ʺA�i�ܫe�ǡB���ǡB��ǡB���h���X��k
    ' ============================================================
    ' �ŧi���O
    Public Class BNode
        ' ���O����
        Public data As Integer = -1
        Public left As BNode
        Public right As BNode
        Public parent As BNode
        Public index As Integer = -1         ' �ʺA�i�ܥ�
        Public left_index As Integer = -1
        Public right_index As Integer = -1
        Public parent_index As Integer = -1
        Public tree_index As Integer = 0     ' �ʺA�i�ܥ�
    End Class

    ' �ŧi�����ܼ�
    Dim null As BNode = Nothing     ' �Ÿ`�I
    Dim HeadNode As BNode = Nothing ' �ŧi�_�Y�`�I
    Dim n As Integer = 15                    ' �}�C�̤j�ƶq
    Dim ValueSize As Integer = 9             ' ��Ƴ̤j�ƶq
    Dim A() As Integer = {5, 3, 7, 2, 9, 4, 6, 8, 1}  ' ��ƶ�

    Dim value_txt(9) As TextBox   ' �ʺA�i�ܤ�TextBox����}�C
    Dim value_lab(9) As Label     ' �ʺA�i�ܤ�Label����}�C

    Dim data_txt(9) As TextBox    ' �ʺA�i�ܤ�TextBox����}�C
    Dim data_lab(9) As Label      ' �ʺA�i�ܤ�Label����}�C
    Dim left_txt(9) As TextBox    ' �ʺA�i�ܤ�TextBox����}�C
    Dim right_txt(9) As TextBox   ' �ʺA�i�ܤ�TextBox����}�C
    Dim parent_txt(9) As TextBox  ' �ʺA�i�ܤ�TextBox����}�C

    Dim tree_txt(15) As TextBox   ' �ʺA�i�ܤ�TextBox����}�C
    Dim tree_lab(15) As Label     ' �ʺA�i�ܤ�Label����}�C

    Dim tree_rowcol(4, 8) As Integer  ' �ʺA�i��tree���y�� row,col-->index
    Dim tree_pos(2, 15) As Integer    ' �ʺA�i��tree���y�� index-->row,col

    Dim PauseTime, Start, Finish, TotalTime As Single
    Dim shiftx, shifty, gapx, gapy As Integer
    Dim shiftx1, shifty1, gapx1, gapy1 As Integer

    ' =========== Program Description ============================
    ' �{���W�� : create_bintree4     �Q�Τ@�Ӱ}�C��ƨӲ��;�
    ' ============================================================
    Sub create_bintree4(ByVal A() As Integer, ByVal m As Integer)
        Dim i, k As Integer
        Dim index As Integer
        Dim parent_index As Integer
        Dim dir_flag As Integer  ' 0:left  1:right
        Dim tree_index As Integer
        Dim WorkNode As BNode = Nothing
        Dim ParentNode As BNode = Nothing

        ' �t��k�}�l
        ' ------------------------------------------
        For i = 0 To m - 1 ' ���J���C����ƳB�z  
            ' �C��:�L�Ŧ�
            value_txt(i).BackColor = System.Drawing.Color.FromArgb(CType(128, Byte), CType(255, Byte), CType(255, Byte))

            If (i = 0) Then
                HeadNode = New BNode
                HeadNode.data = A(i)
                HeadNode.left = null
                HeadNode.right = null
                HeadNode.parent = null
                HeadNode.index = 0
                HeadNode.left_index = -1
                HeadNode.right_index = -1
                HeadNode.parent_index = -1
                HeadNode.tree_index = 0

                ' �ʺA�i��
                ' ---------
                tree_index = 0
                data_txt(0).Text = A(i)
                left_txt(0).Text = -1
                right_txt(0).Text = -1
                parent_txt(0).Text = -1

                tree_txt(0).Text = A(i)
                tree_lab(0).Text = 0
                tree_lab(0).Visible = True
                ' �C��:�L����
                tree_txt(0).BackColor = System.Drawing.Color.FromArgb(CType(255, Byte), CType(128, Byte), CType(128, Byte))
                proPause(0)
                ' --------
            Else
                WorkNode = HeadNode

                index = 0

                ' �ʺA�i��
                ' ---------
                tree_index = 0
                ' ---------

                Do While (index < m) ' ����Ƥp��}�C�j�p�� 

                    ' �ʺA�i��
                    ' ---------
                    ' �C��:�L�Ŧ�
                    tree_txt(tree_index).BackColor = System.Drawing.Color.FromArgb(CType(128, Byte), CType(255, Byte), CType(255, Byte))
                    ' ��border���ܤƳгy�ʪ��ĪG
                    For k = 1 To 4
                        tree_txt(tree_index).BorderStyle = System.Windows.Forms.BorderStyle.None
                        tree_txt(tree_index).BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
                        tree_txt(tree_index).BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
                    Next
                    proPause(tree_index)
                    ' --------

                    ' �@�}�l��Ĥ@����Ʃ�b��0�Ӧ�m 
                    If (WorkNode Is null) Then
                        ' �p�G�O�Ÿ`�I�N���Ʃ�i�h 
                        WorkNode = New BNode
                        WorkNode.data = A(i)
                        WorkNode.left = null
                        WorkNode.right = null
                        WorkNode.parent = ParentNode
                        WorkNode.index = i
                        WorkNode.left_index = -1
                        WorkNode.right_index = -1
                        WorkNode.parent_index = parent_index
                        WorkNode.tree_index = tree_index
                        If dir_flag = 0 Then
                            ParentNode.left = WorkNode
                            ParentNode.left_index = index
                        Else
                            ParentNode.right = WorkNode
                            ParentNode.right_index = index
                        End If

                        ' �ʺA�i��
                        ' ---------
                        data_txt(i).Text = A(i)
                        left_txt(i).Text = -1
                        right_txt(i).Text = -1
                        parent_txt(i).Text = parent_index
                        If dir_flag = 0 Then
                            left_txt(parent_index).Text = i
                        Else
                            right_txt(parent_index).Text = i
                        End If

                        tree_txt(tree_index).Text = A(i)
                        tree_lab(tree_index).Text = i
                        tree_lab(tree_index).Visible = True
                        ' �C��:�L����
                        tree_txt(tree_index).BackColor = System.Drawing.Color.FromArgb(CType(255, Byte), CType(128, Byte), CType(128, Byte))
                        proPause(tree_index)
                        ' ---------

                        Exit Do
                    ElseIf (A(i) > WorkNode.data) Then
                        ' �p�G���`�I����Ȥ���p�A�h���k�䨫
                        dir_flag = 1
                        ParentNode = WorkNode
                        parent_index = WorkNode.index
                        index = WorkNode.right_index

                        WorkNode = WorkNode.right

                        ' �ʺA�i��
                        ' ---------
                        tree_index = (tree_index + 1) * 2
                        ' --------
                    Else
                        ' �p�G���`�I����Ȥ���j�A�h�����䨫
                        dir_flag = 0
                        ParentNode = WorkNode
                        parent_index = WorkNode.index
                        index = WorkNode.left_index

                        WorkNode = WorkNode.left

                        ' �ʺA�i��
                        ' ---------
                        tree_index = (tree_index + 1) * 2 - 1
                        ' ---------
                    End If
                Loop
            End If
        Next
        ' �t��k����
        ' ------------------------------------------
    End Sub

    ' =========== Program Description ============================
    ' �{���W�� : �{���Ұʬɭ�
    ' ============================================================
    Private Sub Form1_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Dim i As Integer

        shiftx = 40 : shifty = 40 : gapx = 20 : gapy = 20
        ' �إ߸�ƪ���}�C
        For i = 0 To ValueSize - 1
            value_txt(i) = New TextBox
            value_txt(i).Multiline = True
            value_txt(i).Width = 20
            value_txt(i).Height = 20
            value_txt(i).Left = shiftx + i * gapx
            value_txt(i).Top = shifty
            value_txt(i).Font = New System.Drawing.Font( _
               "�s�ө���", 9.0!, System.Drawing.FontStyle.Regular, _
               System.Drawing.GraphicsUnit.Point, CType(136, Byte))
            value_txt(i).Text = A(i)
            value_txt(i).TextAlign = HorizontalAlignment.Center

            value_lab(i) = New Label
            value_lab(i).Width = 10
            value_lab(i).Height = 20
            value_lab(i).Left = shiftx + i * gapx + 5
            value_lab(i).Top = shifty - gapy + 5
            value_lab(i).Font = New System.Drawing.Font( _
               "�s�ө���", 9.0!, System.Drawing.FontStyle.Regular, _
               System.Drawing.GraphicsUnit.Point, CType(136, Byte))
            value_lab(i).Text = i

            Me.Controls.Add(value_txt(i))
            Me.Controls.Add(value_lab(i))
        Next

        ' �إ� array ����}�C
        For i = 0 To ValueSize - 1
            data_lab(i) = New Label
            data_lab(i).Width = 16
            data_lab(i).Height = 16
            data_lab(i).Left = shiftx + i * gapx + 5
            data_lab(i).Top = shifty - gapy + 5 + 40
            data_lab(i).Font = New System.Drawing.Font( _
               "�s�ө���", 9.0!, System.Drawing.FontStyle.Regular, _
               System.Drawing.GraphicsUnit.Point, CType(136, Byte))
            data_lab(i).Text = i

            left_txt(i) = New TextBox
            left_txt(i).Multiline = True
            left_txt(i).Width = 20
            left_txt(i).Height = 20
            left_txt(i).Left = shiftx + i * gapx
            left_txt(i).Top = shifty + 40
            left_txt(i).Font = New System.Drawing.Font( _
               "�s�ө���", 9.0!, System.Drawing.FontStyle.Regular, _
               System.Drawing.GraphicsUnit.Point, CType(136, Byte))
            left_txt(i).Text = ""
            left_txt(i).TextAlign = HorizontalAlignment.Center

            data_txt(i) = New TextBox
            data_txt(i).Multiline = True
            data_txt(i).Width = 20
            data_txt(i).Height = 20
            data_txt(i).Left = shiftx + i * gapx
            data_txt(i).Top = shifty + 60
            data_txt(i).Font = New System.Drawing.Font( _
               "�s�ө���", 9.0!, System.Drawing.FontStyle.Regular, _
               System.Drawing.GraphicsUnit.Point, CType(136, Byte))
            data_txt(i).Text = ""
            data_txt(i).TextAlign = HorizontalAlignment.Center

            right_txt(i) = New TextBox
            right_txt(i).Multiline = True
            right_txt(i).Width = 20
            right_txt(i).Height = 20
            right_txt(i).Left = shiftx + i * gapx
            right_txt(i).Top = shifty + 80
            right_txt(i).Font = New System.Drawing.Font( _
               "�s�ө���", 9.0!, System.Drawing.FontStyle.Regular, _
               System.Drawing.GraphicsUnit.Point, CType(136, Byte))
            right_txt(i).Text = ""
            right_txt(i).TextAlign = HorizontalAlignment.Center

            parent_txt(i) = New TextBox
            parent_txt(i).Multiline = True
            parent_txt(i).Width = 20
            parent_txt(i).Height = 20
            parent_txt(i).Left = shiftx + i * gapx
            parent_txt(i).Top = shifty + 100
            parent_txt(i).Font = New System.Drawing.Font( _
               "�s�ө���", 9.0!, System.Drawing.FontStyle.Regular, _
               System.Drawing.GraphicsUnit.Point, CType(136, Byte))
            parent_txt(i).Text = ""
            parent_txt(i).TextAlign = HorizontalAlignment.Center

            Me.Controls.Add(data_lab(i))
            Me.Controls.Add(data_txt(i))
            Me.Controls.Add(left_txt(i))
            Me.Controls.Add(right_txt(i))
            Me.Controls.Add(parent_txt(i))
        Next

        ' �إ� tree ����}�C
        For i = 0 To n - 1
            tree_txt(i) = New TextBox
            tree_txt(i).Multiline = True
            tree_txt(i).Width = 20
            tree_txt(i).Height = 20
            tree_txt(i).Left = shiftx + i * gapx
            tree_txt(i).Top = shifty + 140
            tree_txt(i).Font = New System.Drawing.Font( _
               "�s�ө���", 9.0!, System.Drawing.FontStyle.Regular, _
               System.Drawing.GraphicsUnit.Point, CType(136, Byte))
            tree_txt(i).Text = ""
            tree_txt(i).TextAlign = HorizontalAlignment.Center

            tree_lab(i) = New Label
            tree_lab(i).Width = 16
            tree_lab(i).Height = 20
            tree_lab(i).Left = shiftx + i * gapx + 5
            tree_lab(i).Top = shifty - gapy + 5 + 140
            tree_lab(i).Font = New System.Drawing.Font( _
               "�s�ө���", 9.0!, System.Drawing.FontStyle.Regular, _
               System.Drawing.GraphicsUnit.Point, CType(136, Byte))
            tree_lab(i).Text = i

            Me.Controls.Add(tree_txt(i))
            Me.Controls.Add(tree_lab(i))
        Next
    End Sub

    ' =========== Program Description ============================
    ' �{���W�� : [�إߤG����}�C]���s�� Click �ƥ�
    ' ============================================================
    Private Sub create_but_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles create_but.Click
        create_but.Enabled = False
        preorder_but.Enabled = True
        inorder_but.Enabled = True
        postorder_but.Enabled = True
        levelorder_but.Enabled = True
        create_bintree4(A, ValueSize)
    End Sub

    ' =========== Program Description ============================
    ' �{���W�� : [�}�C�ƦC�𵲺c]���s�� Click �ƥ�
    ' ============================================================
    Private Sub tree_but_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles tree_but.Click
        Call proCalTreePos()
        Call proAssignTree()
    End Sub

    ' =========== Program Description ============================
    ' �{���W�� : proCalTreePos   �p��tree���y�Ц�m
    ' ============================================================
    Sub proCalTreePos()
        Dim i, j As Integer
        Dim row As Integer = 0, col As Integer = 0
        Dim rowcount As Integer = 0

        ' ��l�]�w�� -1
        For i = 0 To 3
            For j = 0 To 7
                tree_rowcol(i, j) = -1
            Next
        Next

        ' �p�� index -> (row,col)
        For i = 0 To n - 1
            tree_rowcol(row, col) = i
            rowcount += 1
            If rowcount >= (2 ^ row) Then
                rowcount = 0
                row += 1
                col = 0
            Else
                col += 1
            End If
        Next

        ' �p��  (row,col) -> index
        For i = 0 To 3
            For j = 0 To 7
                If tree_rowcol(i, j) >= 0 Then
                    ' ��1������ 0 �A�N�� row ��m
                    ' ��1������ 1 �A�N�� col ��m
                    tree_pos(0, tree_rowcol(i, j)) = i
                    tree_pos(1, tree_rowcol(i, j)) = j
                End If
            Next
        Next

    End Sub

    ' =========== Program Description ==============================
    ' �{���W�� : proAssignTree  ��tree�y�Ц�m�A����left,top���𵲺c
    ' ==============================================================
    Sub proAssignTree()
        Dim i As Integer
        Dim row_pos, col_pos As Integer

        shiftx1 = shiftx : shifty1 = shifty + 140 : gapx1 = gapx * 2 : gapy1 = gapy * 2

        ' �̧ǲ���tree���󪺦�m
        For i = 0 To n - 1
            row_pos = tree_pos(0, i)
            col_pos = tree_pos(1, i)
            ' ��m�s��   row=0                               8
            '            row=1               4                               12
            '            row=2       2               6              10               14            
            '            row=3   1       3       5       7       9       11      13     15

            tree_txt(i).Left = shiftx1 + 2 ^ (3 - row_pos) * gapx1 + 2 ^ (4 - row_pos) * col_pos * gapx1
            tree_txt(i).Top = shifty1 + row_pos * gapy1
            tree_lab(i).Left = tree_txt(i).Left - 20
            tree_lab(i).Top = tree_txt(i).Top
            tree_lab(i).Visible = False
        Next
    End Sub

    ' =========== Program Description ============================
    ' �{���W�� : [�e�Ƿj�M�k]���s�� Click �ƥ�
    ' ============================================================
    Private Sub preorder_but_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles preorder_but.Click
        Dim i As Integer

        ' �ʺA�i��
        ' ---------
        ' �C��:�զ�
        preorder_txt.Text = ""
        For i = 0 To n - 1
            tree_txt(i).BackColor = System.Drawing.Color.White
        Next
        ' --------

        Call preorder(HeadNode)
    End Sub

    ' =========== Program Description ============================
    ' �{���W�� : [���Ƿj�M�k]���s�� Click �ƥ�
    ' ============================================================
    Private Sub inorder_but_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles inorder_but.Click
        Dim i As Integer

        ' �ʺA�i��
        ' ---------
        ' �C��:�զ�
        inorder_txt.Text = ""
        For i = 0 To n - 1
            tree_txt(i).BackColor = System.Drawing.Color.White
        Next
        ' --------
        Call inorder(HeadNode)
    End Sub

    ' =========== Program Description ============================
    ' �{���W�� : [��Ƿj�M�k]���s�� Click �ƥ�
    ' ============================================================
    Private Sub postorder_but_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles postorder_but.Click
        Dim i As Integer

        ' �ʺA�i��
        ' ---------
        ' �C��:�զ�
        postorder_txt.Text = ""
        For i = 0 To n - 1
            tree_txt(i).BackColor = System.Drawing.Color.White
        Next
        ' --------
        Call postorder(HeadNode)
    End Sub

    ' =========== Program Description ============================
    ' �{���W�� : [���h�j�M�k]���s�� Click �ƥ�
    ' ============================================================
    Private Sub levelorder_but_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles levelorder_but.Click
        Dim i As Integer

        ' �ʺA�i��
        ' ---------
        ' �C��:�զ�
        levelorder_txt.Text = ""
        For i = 0 To n - 1
            tree_txt(i).BackColor = System.Drawing.Color.White
        Next
        ' --------

        Call levelorder(HeadNode)
    End Sub

    ' =========== Program Description ============================
    ' �{���W�� : proPause   ����Ȱ����{��
    ' ============================================================
    Sub proPause(ByVal index As Integer)
        If auto_rad.Checked Then
            ' �Ȱ��ɶ�����
            PauseTime = 1                ' �]�w�Ȱ��ɶ�
            Start = DateAndTime.Timer    ' �]�w�}�l�Ȱ����ɨ�
            Do While DateAndTime.Timer < Start + PauseTime
                Application.DoEvents()   ' �N�{�������v�����䥦�{��
            Loop
        ElseIf step_rad.Checked Then
            MsgBox("�ثe�ˬd�`�I:" & index)
        End If
    End Sub

    ' =========== Program Description ============================
    ' �{���W�� : preorder   �e�Ǫk���X
    ' ============================================================
    Sub preorder(ByVal node As BNode)
        Dim index, tree_index As Integer
        If (Not (node Is null)) Then
            ' �ʺA�i��
            ' ---------
            ' �C��:�L�Ŧ�
            tree_index = node.tree_index
            index = node.index
            tree_txt(tree_index).BackColor = System.Drawing.Color.FromArgb(CType(128, Byte), CType(255, Byte), CType(255, Byte))
            proPause(index)
            ' --------
            preorder_txt.Text = preorder_txt.Text & node.data & "  "

            ' �ʺA�i��
            ' ---------
            ' �C��:������
            tree_index = node.tree_index
            index = node.index
            tree_txt(tree_index).BackColor = System.Drawing.Color.FromArgb(CType(255, Byte), CType(128, Byte), CType(128, Byte))
            proPause(index)
            ' ---------
            preorder(node.left)
            preorder(node.right)
        End If
    End Sub

    ' =========== Program Description ============================
    ' �{���W�� : inorder   ���Ǫk���X
    ' ============================================================
    Sub inorder(ByVal node As BNode)
        Dim index, tree_index As Integer
        If (Not (node Is null)) Then
            ' �ʺA�i��
            ' ---------
            ' �C��:�L�Ŧ�
            tree_index = node.tree_index
            index = node.index
            tree_txt(tree_index).BackColor = System.Drawing.Color.FromArgb(CType(128, Byte), CType(255, Byte), CType(255, Byte))
            proPause(index)
            ' --------
            inorder(node.left)

            inorder_txt.Text = inorder_txt.Text & node.data & "  "

            ' �ʺA�i��
            ' ---------
            ' �C��:������
            tree_index = node.tree_index
            index = node.index
            tree_txt(tree_index).BackColor = System.Drawing.Color.FromArgb(CType(255, Byte), CType(128, Byte), CType(128, Byte))
            proPause(index)
            ' ---------

            inorder(node.right)
        End If
    End Sub

    ' =========== Program Description ============================
    ' �{���W�� : postorder   ��Ǫk���X
    ' ============================================================
    Sub postorder(ByVal node As BNode)
        Dim index, tree_index As Integer

        If (Not (node Is null)) Then
            ' �ʺA�i��
            ' ---------
            ' �C��:�L�Ŧ�
            tree_index = node.tree_index
            index = node.index
            tree_txt(tree_index).BackColor = System.Drawing.Color.FromArgb(CType(128, Byte), CType(255, Byte), CType(255, Byte))
            proPause(index)
            ' --------

            postorder(node.left)
            postorder(node.right)
            postorder_txt.Text = postorder_txt.Text & node.data & "  "

            ' �ʺA�i��
            ' ---------
            ' �C��:������
            tree_index = node.tree_index
            index = node.index
            tree_txt(tree_index).BackColor = System.Drawing.Color.FromArgb(CType(255, Byte), CType(128, Byte), CType(128, Byte))
            proPause(index)
            ' --------
        End If
    End Sub

    ' =========== Program Description ============================
    ' �{���W�� : levelorder   ���h�k���X
    ' ============================================================
    Sub levelorder(ByVal node As BNode)
        Dim index, tree_index As Integer

        Dim ptr As BNode
        Dim t(15) As BNode
        Dim i As Integer
        Dim front As Integer = -1, rear As Integer = 0

        For i = 0 To n - 1
            t(i) = New BNode
            t(i) = Nothing
        Next
        ptr = node
        Do While (Not (ptr Is null))

            ' �ʺA�i��
            ' ---------
            ' �C��:�L�Ŧ�
            tree_index = ptr.tree_index
            index = ptr.index
            tree_txt(tree_index).BackColor = System.Drawing.Color.FromArgb(CType(128, Byte), CType(255, Byte), CType(255, Byte))
            proPause(index)

            levelorder_txt.Text = levelorder_txt.Text & ptr.data & "  "

            ' �C��:������
            tree_index = ptr.tree_index
            index = ptr.index
            tree_txt(tree_index).BackColor = System.Drawing.Color.FromArgb(CType(255, Byte), CType(128, Byte), CType(128, Byte))
            proPause(index)
            ' --------

            If (Not (ptr.left Is null)) Then
                t(rear) = ptr.left
                rear += 1
            End If

            If (Not (ptr.right Is null)) Then
                t(rear) = ptr.right
                rear += 1
            End If

            If (Not (front = rear)) Then
                front += 1
                ptr = t(front)
            End If
        Loop
    End Sub

End Class


