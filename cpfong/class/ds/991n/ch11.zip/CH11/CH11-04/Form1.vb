Public Class Form1
    Inherits System.Windows.Forms.Form

#Region " Windows Form �]�p�u�㲣�ͪ��{���X "

    Public Sub New()
        MyBase.New()

        '���� Windows Form �]�p�u��һݪ��I�s�C
        InitializeComponent()

        '�b InitializeComponent() �I�s����[�J�Ҧ�����l�]�w

    End Sub

    'Form �мg Dispose �H�M������M��C
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    '�� Windows Form �]�p�u�㪺���n��
    Private components As System.ComponentModel.IContainer

    '�`�N: �H�U�� Windows Form �]�p�u��һݪ��{��
    '�z�i�H�ϥ� Windows Form �]�p�u��i��ק�C
    '�ФŨϥε{���X�s�边�ӭק�o�ǵ{�ǡC
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents search_but As System.Windows.Forms.Button
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents search_txt As System.Windows.Forms.TextBox
    Friend WithEvents tree_but As System.Windows.Forms.Button
    Friend WithEvents create_but As System.Windows.Forms.Button
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents GroupBox1 As System.Windows.Forms.GroupBox
    Friend WithEvents auto_rad As System.Windows.Forms.RadioButton
    Friend WithEvents step_rad As System.Windows.Forms.RadioButton
    Friend WithEvents Label7 As System.Windows.Forms.Label
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.Label2 = New System.Windows.Forms.Label
        Me.search_but = New System.Windows.Forms.Button
        Me.Label1 = New System.Windows.Forms.Label
        Me.search_txt = New System.Windows.Forms.TextBox
        Me.tree_but = New System.Windows.Forms.Button
        Me.create_but = New System.Windows.Forms.Button
        Me.Label6 = New System.Windows.Forms.Label
        Me.Label3 = New System.Windows.Forms.Label
        Me.Label4 = New System.Windows.Forms.Label
        Me.Label5 = New System.Windows.Forms.Label
        Me.GroupBox1 = New System.Windows.Forms.GroupBox
        Me.auto_rad = New System.Windows.Forms.RadioButton
        Me.step_rad = New System.Windows.Forms.RadioButton
        Me.Label7 = New System.Windows.Forms.Label
        Me.GroupBox1.SuspendLayout()
        Me.SuspendLayout()
        '
        'Label2
        '
        Me.Label2.Location = New System.Drawing.Point(0, 88)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(32, 16)
        Me.Label2.TabIndex = 53
        Me.Label2.Text = "Left"
        '
        'search_but
        '
        Me.search_but.Enabled = False
        Me.search_but.Location = New System.Drawing.Point(608, 152)
        Me.search_but.Name = "search_but"
        Me.search_but.Size = New System.Drawing.Size(104, 24)
        Me.search_but.TabIndex = 50
        Me.search_but.Text = "�}�l�j�M"
        '
        'Label1
        '
        Me.Label1.Location = New System.Drawing.Point(608, 96)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(80, 16)
        Me.Label1.TabIndex = 49
        Me.Label1.Text = "�j�M"
        '
        'search_txt
        '
        Me.search_txt.BackColor = System.Drawing.Color.FromArgb(CType(255, Byte), CType(255, Byte), CType(128, Byte))
        Me.search_txt.Location = New System.Drawing.Point(608, 120)
        Me.search_txt.Name = "search_txt"
        Me.search_txt.Size = New System.Drawing.Size(56, 22)
        Me.search_txt.TabIndex = 48
        Me.search_txt.Text = "8"
        '
        'tree_but
        '
        Me.tree_but.Location = New System.Drawing.Point(608, 8)
        Me.tree_but.Name = "tree_but"
        Me.tree_but.Size = New System.Drawing.Size(104, 32)
        Me.tree_but.TabIndex = 46
        Me.tree_but.Text = "�}�C�ƦC�𵲺c"
        '
        'create_but
        '
        Me.create_but.Location = New System.Drawing.Point(608, 48)
        Me.create_but.Name = "create_but"
        Me.create_but.Size = New System.Drawing.Size(104, 32)
        Me.create_but.TabIndex = 45
        Me.create_but.Text = "�إߤG����}�C"
        '
        'Label6
        '
        Me.Label6.Location = New System.Drawing.Point(0, 43)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(32, 16)
        Me.Label6.TabIndex = 56
        Me.Label6.Text = "Value"
        '
        'Label3
        '
        Me.Label3.Location = New System.Drawing.Point(0, 106)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(32, 16)
        Me.Label3.TabIndex = 54
        Me.Label3.Text = "Data"
        '
        'Label4
        '
        Me.Label4.Location = New System.Drawing.Point(0, 126)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(32, 16)
        Me.Label4.TabIndex = 51
        Me.Label4.Text = "Right"
        '
        'Label5
        '
        Me.Label5.Location = New System.Drawing.Point(0, 144)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(40, 16)
        Me.Label5.TabIndex = 52
        Me.Label5.Text = "Parent"
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.auto_rad)
        Me.GroupBox1.Controls.Add(Me.step_rad)
        Me.GroupBox1.Location = New System.Drawing.Point(448, 24)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(144, 48)
        Me.GroupBox1.TabIndex = 47
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "�ާ@�覡"
        '
        'auto_rad
        '
        Me.auto_rad.Checked = True
        Me.auto_rad.Location = New System.Drawing.Point(8, 16)
        Me.auto_rad.Name = "auto_rad"
        Me.auto_rad.Size = New System.Drawing.Size(64, 20)
        Me.auto_rad.TabIndex = 0
        Me.auto_rad.TabStop = True
        Me.auto_rad.Text = "�۰�"
        '
        'step_rad
        '
        Me.step_rad.Location = New System.Drawing.Point(72, 16)
        Me.step_rad.Name = "step_rad"
        Me.step_rad.Size = New System.Drawing.Size(64, 20)
        Me.step_rad.TabIndex = 0
        Me.step_rad.Text = "���"
        '
        'Label7
        '
        Me.Label7.Location = New System.Drawing.Point(0, 184)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(32, 16)
        Me.Label7.TabIndex = 55
        Me.Label7.Text = "Tree"
        '
        'Form1
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 15)
        Me.ClientSize = New System.Drawing.Size(720, 341)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.search_but)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.search_txt)
        Me.Controls.Add(Me.tree_but)
        Me.Controls.Add(Me.create_but)
        Me.Controls.Add(Me.Label6)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.GroupBox1)
        Me.Controls.Add(Me.Label7)
        Me.Name = "Form1"
        Me.Text = "Form1"
        Me.GroupBox1.ResumeLayout(False)
        Me.ResumeLayout(False)

    End Sub

#End Region

    ' =========== Program Description ============================
    ' �{���W�� : CH11-04	
    ' �t��k�G�Q���쵲��C�إߤG����
    ' ��J�G��ư}�C���
    ' ��X�G�ʺA�i�ܸ��|����M�A�B�i�ܧ���G����
    ' ============================================================
    ' �ŧi���O
    Public Class BNode
        ' ���O����
        Public data As Integer = -1
        Public left As BNode
        Public right As BNode
        Public parent As BNode
        Public index As Integer = -1
        Public left_index As Integer = -1
        Public right_index As Integer = -1
        Public parent_index As Integer = -1
    End Class

    ' �ŧi�����ܼ�
    Dim null As BNode = Nothing     ' �Ÿ`�I
    Dim HeadNode As BNode = Nothing ' �ŧi�_�Y�`�I
    Dim n As Integer = 15                    ' �}�C�̤j�ƶq
    Dim ValueSize As Integer = 9             ' ��Ƴ̤j�ƶq
    Dim A() As Integer = {5, 3, 7, 2, 9, 4, 6, 8, 1}  ' ��ƶ�

    Dim value_txt(9) As TextBox   ' �ʺA�i�ܤ�TextBox����}�C
    Dim value_lab(9) As Label     ' �ʺA�i�ܤ�Label����}�C

    Dim data_txt(9) As TextBox    ' �ʺA�i�ܤ�TextBox����}�C
    Dim data_lab(9) As Label      ' �ʺA�i�ܤ�Label����}�C
    Dim left_txt(9) As TextBox    ' �ʺA�i�ܤ�TextBox����}�C
    Dim right_txt(9) As TextBox   ' �ʺA�i�ܤ�TextBox����}�C
    Dim parent_txt(9) As TextBox  ' �ʺA�i�ܤ�TextBox����}�C

    Dim tree_txt(15) As TextBox   ' �ʺA�i�ܤ�TextBox����}�C
    Dim tree_lab(15) As Label     ' �ʺA�i�ܤ�Label����}�C

    Dim tree_rowcol(4, 8) As Integer  ' �ʺA�i��tree���y�� row,col-->index
    Dim tree_pos(2, 15) As Integer    ' �ʺA�i��tree���y�� index-->row,col

    Dim PauseTime, Start, Finish, TotalTime As Single
    Dim shiftx, shifty, gapx, gapy As Integer
    Dim shiftx1, shifty1, gapx1, gapy1 As Integer

    ' =========== Program Description ============================
    ' �{���W�� : create_bintree4     �Q�Τ@�Ӱ}�C��ƨӲ��;�
    ' ============================================================
    Sub create_bintree4(ByVal A() As Integer, ByVal m As Integer)
        Dim i, k As Integer
        Dim index As Integer
        Dim parent_index As Integer
        Dim dir_flag As Integer  ' 0:left  1:right
        Dim tree_index As Integer
        Dim WorkNode As BNode = Nothing
        Dim ParentNode As BNode = Nothing

        ' �t��k�}�l
        ' ------------------------------------------
        For i = 0 To m - 1 ' ���J���C����ƳB�z  
            ' �C��:�L�Ŧ�
            value_txt(i).BackColor = System.Drawing.Color.FromArgb(CType(128, Byte), CType(255, Byte), CType(255, Byte))

            If (i = 0) Then
                HeadNode = New BNode
                HeadNode.data = A(i)
                HeadNode.left = null
                HeadNode.right = null
                HeadNode.parent = null
                HeadNode.index = 0
                HeadNode.left_index = -1
                HeadNode.right_index = -1
                HeadNode.parent_index = -1

                ' �ʺA�i��
                ' ---------
                tree_index = 0
                data_txt(0).Text = A(i)
                left_txt(0).Text = -1
                right_txt(0).Text = -1
                parent_txt(0).Text = -1

                tree_txt(0).Text = A(i)
                tree_lab(0).Text = 0
                tree_lab(0).Visible = True
                ' �C��:�L����
                tree_txt(0).BackColor = System.Drawing.Color.FromArgb(CType(255, Byte), CType(128, Byte), CType(128, Byte))
                proPause(0)
                ' --------
            Else
                WorkNode = HeadNode

                index = 0

                ' �ʺA�i��
                ' ---------
                tree_index = 0
                ' ---------

                Do While (index < m) ' ����Ƥp��}�C�j�p�� 

                    ' �ʺA�i��
                    ' ---------
                    ' �C��:�L�Ŧ�
                    tree_txt(tree_index).BackColor = System.Drawing.Color.FromArgb(CType(128, Byte), CType(255, Byte), CType(255, Byte))
                    ' ��border���ܤƳгy�ʪ��ĪG
                    For k = 1 To 4
                        tree_txt(tree_index).BorderStyle = System.Windows.Forms.BorderStyle.None
                        tree_txt(tree_index).BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
                        tree_txt(tree_index).BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
                    Next
                    proPause(tree_index)
                    ' --------

                    ' �@�}�l��Ĥ@����Ʃ�b��0�Ӧ�m 
                    If (WorkNode Is null) Then
                        ' �p�G�O�Ÿ`�I�N���Ʃ�i�h 
                        WorkNode = New BNode
                        WorkNode.data = A(i)
                        WorkNode.left = null
                        WorkNode.right = null
                        WorkNode.parent = ParentNode
                        WorkNode.index = i
                        WorkNode.left_index = -1
                        WorkNode.right_index = -1
                        WorkNode.parent_index = parent_index
                        If dir_flag = 0 Then
                            ParentNode.left = WorkNode
                            ParentNode.left_index = index
                        Else
                            ParentNode.right = WorkNode
                            ParentNode.right_index = index
                        End If

                        ' �ʺA�i��
                        ' ---------
                        data_txt(i).Text = A(i)
                        left_txt(i).Text = -1
                        right_txt(i).Text = -1
                        parent_txt(i).Text = parent_index
                        If dir_flag = 0 Then
                            left_txt(parent_index).Text = i
                        Else
                            right_txt(parent_index).Text = i
                        End If

                        tree_txt(tree_index).Text = A(i)
                        tree_lab(tree_index).Text = i
                        tree_lab(tree_index).Visible = True
                        ' �C��:�L����
                        tree_txt(tree_index).BackColor = System.Drawing.Color.FromArgb(CType(255, Byte), CType(128, Byte), CType(128, Byte))
                        proPause(tree_index)
                        ' ---------

                        Exit Do
                    ElseIf (A(i) > WorkNode.data) Then
                        ' �p�G���`�I����Ȥ���p�A�h���k�䨫
                        dir_flag = 1
                        ParentNode = WorkNode
                        parent_index = WorkNode.index
                        index = WorkNode.right_index

                        WorkNode = WorkNode.right

                        ' �ʺA�i��
                        ' ---------
                        tree_index = (tree_index + 1) * 2
                        ' --------
                    Else
                        ' �p�G���`�I����Ȥ���j�A�h�����䨫
                        dir_flag = 0
                        ParentNode = WorkNode
                        parent_index = WorkNode.index
                        index = WorkNode.left_index

                        WorkNode = WorkNode.left

                        ' �ʺA�i��
                        ' ---------
                        tree_index = (tree_index + 1) * 2 - 1
                        ' ---------
                    End If
                Loop
            End If
        Next
        ' �t��k����
        ' ------------------------------------------
    End Sub

    ' =========== Program Description ============================
    ' �{���W�� : �{���Ұʬɭ�
    ' ============================================================
    Private Sub Form1_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Dim i As Integer

        ' �إ߸`�I����
        '        For i = 0 To ValueSize - 1
        '        NodeTree(i) = New BNode
        '        Next

        shiftx = 40 : shifty = 40 : gapx = 20 : gapy = 20
        ' �إ߸�ƪ���}�C
        For i = 0 To ValueSize - 1
            value_txt(i) = New TextBox
            value_txt(i).Multiline = True
            value_txt(i).Width = 20
            value_txt(i).Height = 20
            value_txt(i).Left = shiftx + i * gapx
            value_txt(i).Top = shifty
            value_txt(i).Font = New System.Drawing.Font( _
               "�s�ө���", 9.0!, System.Drawing.FontStyle.Regular, _
               System.Drawing.GraphicsUnit.Point, CType(136, Byte))
            value_txt(i).Text = A(i)
            value_txt(i).TextAlign = HorizontalAlignment.Center

            value_lab(i) = New Label
            value_lab(i).Width = 10
            value_lab(i).Height = 20
            value_lab(i).Left = shiftx + i * gapx + 5
            value_lab(i).Top = shifty - gapy + 5
            value_lab(i).Font = New System.Drawing.Font( _
               "�s�ө���", 9.0!, System.Drawing.FontStyle.Regular, _
               System.Drawing.GraphicsUnit.Point, CType(136, Byte))
            value_lab(i).Text = i

            Me.Controls.Add(value_txt(i))
            Me.Controls.Add(value_lab(i))
        Next

        ' �إ� array ����}�C
        For i = 0 To ValueSize - 1
            data_lab(i) = New Label
            data_lab(i).Width = 16
            data_lab(i).Height = 16
            data_lab(i).Left = shiftx + i * gapx + 5
            data_lab(i).Top = shifty - gapy + 5 + 40
            data_lab(i).Font = New System.Drawing.Font( _
               "�s�ө���", 9.0!, System.Drawing.FontStyle.Regular, _
               System.Drawing.GraphicsUnit.Point, CType(136, Byte))
            data_lab(i).Text = i

            left_txt(i) = New TextBox
            left_txt(i).Multiline = True
            left_txt(i).Width = 20
            left_txt(i).Height = 20
            left_txt(i).Left = shiftx + i * gapx
            left_txt(i).Top = shifty + 40
            left_txt(i).Font = New System.Drawing.Font( _
               "�s�ө���", 9.0!, System.Drawing.FontStyle.Regular, _
               System.Drawing.GraphicsUnit.Point, CType(136, Byte))
            left_txt(i).Text = ""
            left_txt(i).TextAlign = HorizontalAlignment.Center

            data_txt(i) = New TextBox
            data_txt(i).Multiline = True
            data_txt(i).Width = 20
            data_txt(i).Height = 20
            data_txt(i).Left = shiftx + i * gapx
            data_txt(i).Top = shifty + 60
            data_txt(i).Font = New System.Drawing.Font( _
               "�s�ө���", 9.0!, System.Drawing.FontStyle.Regular, _
               System.Drawing.GraphicsUnit.Point, CType(136, Byte))
            data_txt(i).Text = ""
            data_txt(i).TextAlign = HorizontalAlignment.Center

            right_txt(i) = New TextBox
            right_txt(i).Multiline = True
            right_txt(i).Width = 20
            right_txt(i).Height = 20
            right_txt(i).Left = shiftx + i * gapx
            right_txt(i).Top = shifty + 80
            right_txt(i).Font = New System.Drawing.Font( _
               "�s�ө���", 9.0!, System.Drawing.FontStyle.Regular, _
               System.Drawing.GraphicsUnit.Point, CType(136, Byte))
            right_txt(i).Text = ""
            right_txt(i).TextAlign = HorizontalAlignment.Center

            parent_txt(i) = New TextBox
            parent_txt(i).Multiline = True
            parent_txt(i).Width = 20
            parent_txt(i).Height = 20
            parent_txt(i).Left = shiftx + i * gapx
            parent_txt(i).Top = shifty + 100
            parent_txt(i).Font = New System.Drawing.Font( _
               "�s�ө���", 9.0!, System.Drawing.FontStyle.Regular, _
               System.Drawing.GraphicsUnit.Point, CType(136, Byte))
            parent_txt(i).Text = ""
            parent_txt(i).TextAlign = HorizontalAlignment.Center

            Me.Controls.Add(data_lab(i))
            Me.Controls.Add(data_txt(i))
            Me.Controls.Add(left_txt(i))
            Me.Controls.Add(right_txt(i))
            Me.Controls.Add(parent_txt(i))
        Next

        ' �إ� tree ����}�C
        For i = 0 To n - 1
            tree_txt(i) = New TextBox
            tree_txt(i).Multiline = True
            tree_txt(i).Width = 20
            tree_txt(i).Height = 20
            tree_txt(i).Left = shiftx + i * gapx
            tree_txt(i).Top = shifty + 140
            tree_txt(i).Font = New System.Drawing.Font( _
               "�s�ө���", 9.0!, System.Drawing.FontStyle.Regular, _
               System.Drawing.GraphicsUnit.Point, CType(136, Byte))
            tree_txt(i).Text = ""
            tree_txt(i).TextAlign = HorizontalAlignment.Center

            tree_lab(i) = New Label
            tree_lab(i).Width = 16
            tree_lab(i).Height = 20
            tree_lab(i).Left = shiftx + i * gapx + 5
            tree_lab(i).Top = shifty - gapy + 5 + 140
            tree_lab(i).Font = New System.Drawing.Font( _
               "�s�ө���", 9.0!, System.Drawing.FontStyle.Regular, _
               System.Drawing.GraphicsUnit.Point, CType(136, Byte))
            tree_lab(i).Text = i

            Me.Controls.Add(tree_txt(i))
            Me.Controls.Add(tree_lab(i))
        Next
    End Sub

    ' =========== Program Description ============================
    ' �{���W�� : [�إߤG����}�C]���s�� Click �ƥ�
    ' ============================================================
    Private Sub create_but_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles create_but.Click
        create_but.Enabled = False
        search_but.Enabled = True
        create_bintree4(A, ValueSize)
    End Sub

    ' =========== Program Description ============================
    ' �{���W�� : [�}�C�ƦC�𵲺c]���s�� Click �ƥ�
    ' ============================================================
    Private Sub tree_but_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles tree_but.Click
        Call proCalTreePos()
        Call proAssignTree()
    End Sub

    ' =========== Program Description ============================
    ' �{���W�� : proCalTreePos   �p��tree���y�Ц�m
    ' ============================================================
    Sub proCalTreePos()
        Dim i, j As Integer
        Dim row As Integer = 0, col As Integer = 0
        Dim rowcount As Integer = 0

        ' ��l�]�w�� -1
        For i = 0 To 3
            For j = 0 To 7
                tree_rowcol(i, j) = -1
            Next
        Next

        ' �p�� index -> (row,col)
        For i = 0 To n - 1
            tree_rowcol(row, col) = i
            rowcount += 1
            If rowcount >= (2 ^ row) Then
                rowcount = 0
                row += 1
                col = 0
            Else
                col += 1
            End If
        Next

        ' �p��  (row,col) -> index
        For i = 0 To 3
            For j = 0 To 7
                If tree_rowcol(i, j) >= 0 Then
                    ' ��1������ 0 �A�N�� row ��m
                    ' ��1������ 1 �A�N�� col ��m
                    tree_pos(0, tree_rowcol(i, j)) = i
                    tree_pos(1, tree_rowcol(i, j)) = j
                End If
            Next
        Next

    End Sub

    ' =========== Program Description ==============================
    ' �{���W�� : proAssignTree  ��tree�y�Ц�m�A����left,top���𵲺c
    ' ==============================================================
    Sub proAssignTree()
        Dim i As Integer
        Dim row_pos, col_pos As Integer

        shiftx1 = shiftx : shifty1 = shifty + 140 : gapx1 = gapx * 2 : gapy1 = gapy * 2

        ' �̧ǲ���tree���󪺦�m
        For i = 0 To n - 1
            row_pos = tree_pos(0, i)
            col_pos = tree_pos(1, i)
            ' ��m�s��   row=0                               8
            '            row=1               4                               12
            '            row=2       2               6              10               14            
            '            row=3   1       3       5       7       9       11      13     15

            tree_txt(i).Left = shiftx1 + 2 ^ (3 - row_pos) * gapx1 + 2 ^ (4 - row_pos) * col_pos * gapx1
            tree_txt(i).Top = shifty1 + row_pos * gapy1
            tree_lab(i).Left = tree_txt(i).Left - 20
            tree_lab(i).Top = tree_txt(i).Top
            tree_lab(i).Visible = False
        Next
    End Sub

    ' =========== Program Description ============================
    ' �{���W�� : [�}�l�j�M]���s�� Click �ƥ�
    ' ============================================================
    Private Sub search_but_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles search_but.Click
        Dim i As Integer
        Dim index, value As Integer
        Dim xflag As Boolean
        Dim tree_index As Integer
        Dim WorkNode As BNode

        ' �ʺA�i��
        ' --------
        ' �C�� : �զ�
        For i = 0 To n - 1
            tree_txt(i).BackColor = System.Drawing.Color.White
        Next
        ' --------

        index = 0
        tree_index = 0
        xflag = True
        value = Val(search_txt.Text)

        WorkNode = HeadNode
        Do While (xflag = True)

            ' �ʺA�i��
            ' --------
            ' �C�� : �L����
            tree_txt(tree_index).BackColor = System.Drawing.Color.FromArgb(CType(255, Byte), CType(255, Byte), CType(128, Byte))
            ' --------

            If (WorkNode.data = value) Then
                MsgBox("����ƤF")
                xflag = False
            ElseIf (WorkNode.data < value) Then
                index = WorkNode.right_index
                WorkNode = WorkNode.right
                ' �ʺA�i��
                ' --------
                tree_index = (tree_index + 1) * 2
                ' --------
                If WorkNode Is null Then Exit Do
            Else
                index = WorkNode.left_index
                WorkNode = WorkNode.left
                ' �ʺA�i��
                ' --------
                tree_index = (tree_index + 1) * 2 - 1
                ' --------
                If WorkNode Is null Then Exit Do
            End If
        Loop
        If xflag = True Then
            MsgBox("�������:" & value)
        End If
    End Sub

    ' =========== Program Description ============================
    ' �{���W�� : proPause   ����Ȱ����{��
    ' ============================================================
    Sub proPause(ByVal index As Integer)
        If auto_rad.Checked Then
            ' �Ȱ��ɶ�����
            PauseTime = 1                ' �]�w�Ȱ��ɶ�
            Start = DateAndTime.Timer    ' �]�w�}�l�Ȱ����ɨ�
            Do While DateAndTime.Timer < Start + PauseTime
                Application.DoEvents()   ' �N�{�������v�����䥦�{��
            Loop
        Else
            MsgBox("�ثe�ˬd�`�I:" & index)
        End If
    End Sub
End Class
