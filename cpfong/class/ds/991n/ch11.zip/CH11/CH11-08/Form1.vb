Public Class Form1
    Inherits System.Windows.Forms.Form

#Region " Windows Form �]�p�u�㲣�ͪ��{���X "

    Public Sub New()
        MyBase.New()

        '���� Windows Form �]�p�u��һݪ��I�s�C
        InitializeComponent()

        '�b InitializeComponent() �I�s����[�J�Ҧ�����l�]�w

    End Sub

    'Form �мg Dispose �H�M������M��C
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    '�� Windows Form �]�p�u�㪺���n��
    Private components As System.ComponentModel.IContainer

    '�`�N: �H�U�� Windows Form �]�p�u��һݪ��{��
    '�z�i�H�ϥ� Windows Form �]�p�u��i��ק�C
    '�ФŨϥε{���X�s�边�ӭק�o�ǵ{�ǡC
    Friend WithEvents GroupBox1 As System.Windows.Forms.GroupBox
    Friend WithEvents auto_rad As System.Windows.Forms.RadioButton
    Friend WithEvents step_rad As System.Windows.Forms.RadioButton
    Friend WithEvents tree_but As System.Windows.Forms.Button
    Friend WithEvents create_but As System.Windows.Forms.Button
    Friend WithEvents heapsort_but As System.Windows.Forms.Button
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox
        Me.auto_rad = New System.Windows.Forms.RadioButton
        Me.step_rad = New System.Windows.Forms.RadioButton
        Me.tree_but = New System.Windows.Forms.Button
        Me.create_but = New System.Windows.Forms.Button
        Me.heapsort_but = New System.Windows.Forms.Button
        Me.GroupBox1.SuspendLayout()
        Me.SuspendLayout()
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.auto_rad)
        Me.GroupBox1.Controls.Add(Me.step_rad)
        Me.GroupBox1.Location = New System.Drawing.Point(448, 24)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(144, 40)
        Me.GroupBox1.TabIndex = 39
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "�ާ@�覡"
        '
        'auto_rad
        '
        Me.auto_rad.Location = New System.Drawing.Point(8, 16)
        Me.auto_rad.Name = "auto_rad"
        Me.auto_rad.Size = New System.Drawing.Size(64, 20)
        Me.auto_rad.TabIndex = 0
        Me.auto_rad.Text = "�۰�"
        '
        'step_rad
        '
        Me.step_rad.Checked = True
        Me.step_rad.Location = New System.Drawing.Point(72, 16)
        Me.step_rad.Name = "step_rad"
        Me.step_rad.Size = New System.Drawing.Size(64, 20)
        Me.step_rad.TabIndex = 0
        Me.step_rad.TabStop = True
        Me.step_rad.Text = "���"
        '
        'tree_but
        '
        Me.tree_but.Location = New System.Drawing.Point(608, 8)
        Me.tree_but.Name = "tree_but"
        Me.tree_but.Size = New System.Drawing.Size(104, 32)
        Me.tree_but.TabIndex = 38
        Me.tree_but.Text = "�}�C�ƦC�𵲺c"
        '
        'create_but
        '
        Me.create_but.Location = New System.Drawing.Point(608, 48)
        Me.create_but.Name = "create_but"
        Me.create_but.Size = New System.Drawing.Size(104, 32)
        Me.create_but.TabIndex = 37
        Me.create_but.Text = "�إ̤߳p��n"
        '
        'heapsort_but
        '
        Me.heapsort_but.Enabled = False
        Me.heapsort_but.Location = New System.Drawing.Point(608, 88)
        Me.heapsort_but.Name = "heapsort_but"
        Me.heapsort_but.Size = New System.Drawing.Size(104, 32)
        Me.heapsort_but.TabIndex = 40
        Me.heapsort_but.Text = "����heap�Ƨ�"
        '
        'Form1
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 15)
        Me.ClientSize = New System.Drawing.Size(720, 333)
        Me.Controls.Add(Me.heapsort_but)
        Me.Controls.Add(Me.GroupBox1)
        Me.Controls.Add(Me.tree_but)
        Me.Controls.Add(Me.create_but)
        Me.Name = "Form1"
        Me.Text = "Form1"
        Me.GroupBox1.ResumeLayout(False)
        Me.ResumeLayout(False)

    End Sub

#End Region

    ' =================================================
    ' �{���W�� : CH11-08
    ' �t��k�W�١G��n�ƧǺt��k
    ' ��J�G�Ƨǫe��ư}�C���
    ' ��X�G�Ƨǫe��ư}�C���
    ' ================================================= 
    ' �ŧi�����ܼ�
    Dim n As Integer = 15               ' �}�C�̤j�ƶq
    Dim ValueSize As Integer = 10       ' ��Ƴ̤j�ƶq
    Dim Tree(15) As Integer ' �𪺰}�C���
    Dim A() As Integer = {17, 19, 21, 55, 23, 12, 99, 44, 37, 44}  ' ��ƶ�

    Dim array_txt(15) As TextBox   ' �ʺA�i�ܤ�TextBox����}�C
    Dim array_lab(15) As Label     ' �ʺA�i�ܤ�Label����}�C

    Dim tree_txt(15) As TextBox   ' �ʺA�i�ܤ�TextBox����}�C
    Dim tree_lab(15) As Label     ' �ʺA�i�ܤ�Label����}�C

    Dim value_txt(15) As TextBox  ' �ʺA�i�ܤ�TextBox����}�C
    Dim value_lab(15) As Label    ' �ʺA�i�ܤ�Label����}�C
    Dim PauseTime, Start, Finish, TotalTime As Single

    Dim tree_rowcol(4, 8) As Integer  ' �ʺA�i��tree���y�� row,col-->index
    Dim tree_pos(2, 15) As Integer    ' �ʺA�i��tree���y�� index-->row,col

    Dim shiftx, shifty, gapx, gapy As Integer
    Dim shiftx1, shifty1, gapx1, gapy1 As Integer

    ' =========== Program Description ============================
    ' �{���W�� : create_bintree     �Q�Τ@�Ӱ}�C��ƨӲ��;�
    ' ============================================================
    Sub create_bintree(ByVal A() As Integer, ByVal m As Integer)
        Dim i, j, k As Integer

        For i = 0 To m - 1 ' ���J���C����ƳB�z  
            j = 0

            ' �ʺA�i��
            ' --------
            ' �C��:�L�Ŧ�
            value_txt(i).BackColor = System.Drawing.Color.FromArgb(CType(128, Byte), CType(255, Byte), CType(255, Byte))
            tree_txt(0).BackColor = System.Drawing.Color.FromArgb(CType(128, Byte), CType(255, Byte), CType(255, Byte))
            ' ��border���ܤƳгy�ʪ��ĪG
            For k = 1 To 4
                tree_txt(0).BorderStyle = System.Windows.Forms.BorderStyle.None
                tree_txt(0).BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
                tree_txt(0).BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
            Next
            If auto_rad.Checked Then
                ' �Ȱ��ɶ�����
                PauseTime = 1                ' �]�w�Ȱ��ɶ�
                Start = DateAndTime.Timer    ' �]�w�}�l�Ȱ����ɨ�
                Do While DateAndTime.Timer < Start + PauseTime
                    Application.DoEvents()   ' �N�{�������v�����䥦�{��
                Loop
            Else
                MsgBox("�ثe�ˬd�`�I:" & 0)
            End If
            ' --------

            Do While (j < n) ' ����Ƥp��}�C�j�p�� 
                ' �@�}�l��Ĥ@����Ʃ�b��0�Ӧ�m 
                If (j = 0) Then
                    If (Tree(0) = -1) Then
                        Tree(0) = A(i)

                        ' �ʺA�i��
                        ' --------
                        array_txt(0).Text = A(i)
                        tree_txt(0).Text = A(i)
                        ' �C��:�L����
                        tree_txt(0).BackColor = System.Drawing.Color.FromArgb(CType(255, Byte), CType(128, Byte), CType(128, Byte))
                        If auto_rad.Checked Then
                            ' �Ȱ��ɶ�����
                            PauseTime = 1                ' �]�w�Ȱ��ɶ�
                            Start = DateAndTime.Timer    ' �]�w�}�l�Ȱ����ɨ�
                            Do While DateAndTime.Timer < Start + PauseTime
                                Application.DoEvents()   ' �N�{�������v�����䥦�{��
                            Loop
                        Else
                            MsgBox("�ثe�ˬd�`�I:" & 0)
                        End If
                        ' ---------

                        Exit Do
                    Else
                        j += 1
                    End If
                End If

                If (Tree(j - 1) = -1) Then
                    ' �p�G�O�Ÿ`�I�N���Ʃ�i�h 
                    Tree(j - 1) = A(i)

                    ' �ʺA�i��
                    ' --------
                    array_txt(j - 1).Text = A(i)
                    tree_txt(j - 1).Text = A(i)
                    ' �C��:�L����
                    tree_txt(j - 1).BackColor = System.Drawing.Color.FromArgb(CType(255, Byte), CType(128, Byte), CType(128, Byte))
                    If auto_rad.Checked Then
                        ' �Ȱ��ɶ�����
                        PauseTime = 1                ' �]�w�Ȱ��ɶ�
                        Start = DateAndTime.Timer    ' �]�w�}�l�Ȱ����ɨ�
                        Do While DateAndTime.Timer < Start + PauseTime
                            Application.DoEvents()   ' �N�{�������v�����䥦�{��
                        Loop
                    Else
                        MsgBox("�ثe�ˬd�`�I:" & j - 1)
                    End If
                    ' ---------

                    Exit Do
                ElseIf (A(i) > Tree(j - 1)) Then
                    ' �p�G���`�I����Ȥ���p�A�h���k�䨫
                    j = j * 2 + 1

                    ' �ʺA�i��
                    ' --------
                    ' �C��:�L�Ŧ�
                    tree_txt(j - 1).BackColor = System.Drawing.Color.FromArgb(CType(128, Byte), CType(255, Byte), CType(255, Byte))
                    For k = 1 To 4
                        tree_txt(j - 1).BorderStyle = System.Windows.Forms.BorderStyle.None
                        tree_txt(j - 1).BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
                        tree_txt(j - 1).BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
                    Next
                    If auto_rad.Checked Then
                        ' �Ȱ��ɶ�����
                        PauseTime = 1                ' �]�w�Ȱ��ɶ�
                        Start = DateAndTime.Timer    ' �]�w�}�l�Ȱ����ɨ�
                        Do While DateAndTime.Timer < Start + PauseTime
                            Application.DoEvents()   ' �N�{�������v�����䥦�{��
                        Loop
                    Else
                        MsgBox("�ثe�ˬd�`�I:" & j - 1)
                    End If
                    ' ---------

                Else
                    ' �p�G���`�I����Ȥ���j�A�h�����䨫
                    j = j * 2

                    ' �ʺA�i��
                    ' --------
                    tree_txt(j - 1).BackColor = System.Drawing.Color.FromArgb(CType(128, Byte), CType(255, Byte), CType(255, Byte))
                    ' ��border���ܤƳгy�ʪ��ĪG
                    For k = 1 To 4
                        tree_txt(j - 1).BorderStyle = System.Windows.Forms.BorderStyle.None
                        tree_txt(j - 1).BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
                        tree_txt(j - 1).BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
                    Next
                    If auto_rad.Checked Then
                        ' �Ȱ��ɶ�����
                        PauseTime = 1                ' �]�w�Ȱ��ɶ�
                        Start = DateAndTime.Timer    ' �]�w�}�l�Ȱ����ɨ�
                        Do While DateAndTime.Timer < Start + PauseTime
                            Application.DoEvents()   ' �N�{�������v�����䥦�{��
                        Loop
                    Else
                        MsgBox("�ثe�ˬd�`�I:" & j - 1)
                    End If
                    ' ---------

                End If
            Loop
        Next
    End Sub

    ' =========== Program Description ============================
    ' �{���W�� : �{���Ұʬɭ�
    ' ============================================================
    Private Sub Form1_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Dim i As Integer

        shiftx = 40 : shifty = 40 : gapx = 20 : gapy = 20
        ' �إ߸�ƪ���}�C
        For i = 0 To ValueSize - 1
            value_txt(i) = New TextBox
            value_txt(i).Multiline = True
            value_txt(i).Width = 20
            value_txt(i).Height = 20
            value_txt(i).Left = shiftx + i * gapx
            value_txt(i).Top = shifty
            value_txt(i).Font = New System.Drawing.Font( _
               "�s�ө���", 9.0!, System.Drawing.FontStyle.Regular, _
               System.Drawing.GraphicsUnit.Point, CType(136, Byte))
            value_txt(i).Text = A(i)
            value_txt(i).TextAlign = HorizontalAlignment.Center

            value_lab(i) = New Label
            value_lab(i).Width = 10
            value_lab(i).Height = 20
            value_lab(i).Left = shiftx + i * gapx + 5
            value_lab(i).Top = shifty - gapy + 5
            value_lab(i).Font = New System.Drawing.Font( _
               "�s�ө���", 9.0!, System.Drawing.FontStyle.Regular, _
               System.Drawing.GraphicsUnit.Point, CType(136, Byte))
            value_lab(i).Text = i

            Me.Controls.Add(value_txt(i))
            Me.Controls.Add(value_lab(i))
        Next

        ' �إ� array ����}�C
        For i = 0 To n - 1
            array_txt(i) = New TextBox
            array_txt(i).Multiline = True
            array_txt(i).Width = 20
            array_txt(i).Height = 20
            array_txt(i).Left = shiftx + i * gapx
            array_txt(i).Top = shifty + 40
            array_txt(i).Font = New System.Drawing.Font( _
               "�s�ө���", 9.0!, System.Drawing.FontStyle.Regular, _
               System.Drawing.GraphicsUnit.Point, CType(136, Byte))
            array_txt(i).Text = ""
            array_txt(i).TextAlign = HorizontalAlignment.Center

            array_lab(i) = New Label
            array_lab(i).Width = 16
            array_lab(i).Height = 20
            array_lab(i).Left = shiftx + i * gapx + 5
            array_lab(i).Top = shifty - gapy + 5 + 40
            array_lab(i).Font = New System.Drawing.Font( _
               "�s�ө���", 9.0!, System.Drawing.FontStyle.Regular, _
               System.Drawing.GraphicsUnit.Point, CType(136, Byte))
            array_lab(i).Text = i

            Me.Controls.Add(array_txt(i))
            Me.Controls.Add(array_lab(i))
        Next

        ' �إ� tree ����}�C
        For i = 0 To n - 1
            tree_txt(i) = New TextBox
            tree_txt(i).Multiline = True
            tree_txt(i).Width = 20
            tree_txt(i).Height = 20
            tree_txt(i).Left = shiftx + i * gapx
            tree_txt(i).Top = shifty + 80
            tree_txt(i).Font = New System.Drawing.Font( _
               "�s�ө���", 9.0!, System.Drawing.FontStyle.Regular, _
               System.Drawing.GraphicsUnit.Point, CType(136, Byte))
            tree_txt(i).Text = ""
            tree_txt(i).TextAlign = HorizontalAlignment.Center

            tree_lab(i) = New Label
            tree_lab(i).Width = 16
            tree_lab(i).Height = 20
            tree_lab(i).Left = shiftx + i * gapx + 5
            tree_lab(i).Top = shifty - gapy + 5 + 80
            tree_lab(i).Font = New System.Drawing.Font( _
               "�s�ө���", 9.0!, System.Drawing.FontStyle.Regular, _
               System.Drawing.GraphicsUnit.Point, CType(136, Byte))
            tree_lab(i).Text = i

            Me.Controls.Add(tree_txt(i))
            Me.Controls.Add(tree_lab(i))
        Next

        For i = 0 To n - 1
            Tree(i) = -1
        Next
    End Sub

    ' =========== Program Description ============================
    ' �{���W�� : [�إߤG����}�C]���s�� Click �ƥ�
    ' ============================================================
    Private Sub create_but_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles create_but.Click
        create_but.Enabled = False
        heapsort_but.Enabled = True
        createheap(A)
    End Sub

    ' =========== Program Description ============================
    ' �{���W�� : [�}�C�ƦC�𵲺c]���s�� Click �ƥ�
    ' ============================================================
    Private Sub tree_but_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles tree_but.Click
        Call proCalTreePos()
        Call proAssignTree()
    End Sub

    ' =========== Program Description ============================
    ' �{���W�� : proCalTreePos   �p��tree���y�Ц�m
    ' ============================================================
    Sub proCalTreePos()
        Dim i, j As Integer
        Dim row As Integer = 0, col As Integer = 0
        Dim rowcount As Integer = 0

        ' ��l�]�w�� -1
        For i = 0 To 3
            For j = 0 To 7
                tree_rowcol(i, j) = -1
            Next
        Next

        ' �p�� index -> (row,col)
        For i = 0 To n - 1
            tree_rowcol(row, col) = i
            rowcount += 1
            If rowcount >= (2 ^ row) Then
                rowcount = 0
                row += 1
                col = 0
            Else
                col += 1
            End If
        Next

        ' �p��  (row,col) -> index
        For i = 0 To 3
            For j = 0 To 7
                If tree_rowcol(i, j) >= 0 Then
                    ' ��1������ 0 �A�N�� row ��m
                    ' ��1������ 1 �A�N�� col ��m
                    tree_pos(0, tree_rowcol(i, j)) = i
                    tree_pos(1, tree_rowcol(i, j)) = j
                End If
            Next
        Next

    End Sub

    ' =========== Program Description ==============================
    ' �{���W�� : proAssignTree  ��tree�y�Ц�m�A����left,top���𵲺c
    ' ==============================================================
    Sub proAssignTree()
        Dim i As Integer
        Dim row_pos, col_pos As Integer

        shiftx1 = shiftx : shifty1 = shifty + 100 : gapx1 = gapx * 2 : gapy1 = gapy * 2

        ' �̧ǲ���tree���󪺦�m
        For i = 0 To n - 1
            row_pos = tree_pos(0, i)
            col_pos = tree_pos(1, i)
            ' ��m�s��   row=0                               8
            '            row=1               4                               12
            '            row=2       2               6              10               14            
            '            row=3   1       3       5       7       9       11      13     15

            tree_txt(i).Left = shiftx1 + 2 ^ (3 - row_pos) * gapx1 + 2 ^ (4 - row_pos) * col_pos * gapx1
            tree_txt(i).Top = shifty1 + row_pos * gapy1
            tree_lab(i).Left = tree_txt(i).Left - 20
            tree_lab(i).Top = tree_txt(i).Top
        Next
    End Sub

    ' =========== Program Description ============================
    ' �{���W�� : swap   �洫�}�C������Ӧ�m����
    ' ============================================================
    Sub swap(ByRef A() As Integer, ByVal pos1 As Integer, ByVal pos2 As Integer)
        Dim temp As Integer
        Dim tempstr As String

        temp = A(pos1)
        A(pos1) = A(pos2)
        A(pos2) = temp

        ' �ʺA�i��
        ' ----------
        tempstr = array_txt(pos1).Text
        array_txt(pos1).Text = array_txt(pos2).Text
        array_txt(pos2).Text = tempstr

        tempstr = tree_txt(pos1).Text
        tree_txt(pos1).Text = tree_txt(pos2).Text
        tree_txt(pos2).Text = tempstr

        ' �C��:�L����
        tree_txt(pos1).BackColor = System.Drawing.Color.FromArgb(CType(255, Byte), CType(128, Byte), CType(128, Byte))
        ' �C��:�L�Ŧ�
        tree_txt(pos2).BackColor = System.Drawing.Color.FromArgb(CType(128, Byte), CType(255, Byte), CType(255, Byte))
        If auto_rad.Checked Then
            ' �Ȱ��ɶ�����
            PauseTime = 1                ' �]�w�Ȱ��ɶ�
            Start = DateAndTime.Timer    ' �]�w�}�l�Ȱ����ɨ�
            Do While DateAndTime.Timer < Start + PauseTime
                Application.DoEvents()   ' �N�{�������v�����䥦�{��
            Loop
        Else
            MsgBox("�ثe��ƥ洫�I:" & pos1 & "-" & pos2)
        End If
        ' ----------
    End Sub

    ' =========== Program Description ============================
    ' �{���W�� : createheap  �إ߰�n
    ' ============================================================
    Sub createheap(ByRef num() As Integer)
        Dim i, s, p As Integer
        Dim heap(10) As Integer

        For i = 0 To ValueSize - 1
            heap(i) = -1
            ' �ʺA�i��
            ' ----------
            array_txt(i).Text = heap(i)
            ' ----------
        Next

        For i = 0 To ValueSize - 1 ' ���J���C����ƳB�z 
            heap(i) = num(i)
            ' �ʺA�i��
            ' ----------
            array_txt(i).Text = heap(i)
            tree_txt(i).Text = heap(i)
            If auto_rad.Checked Then
                ' �Ȱ��ɶ�����
                PauseTime = 1                ' �]�w�Ȱ��ɶ�
                Start = DateAndTime.Timer    ' �]�w�}�l�Ȱ����ɨ�
                Do While DateAndTime.Timer < Start + PauseTime
                    Application.DoEvents()   ' �N�{�������v�����䥦�{��
                Loop
            Else
                MsgBox("�ثe�ˬd�`�I:" & i)
            End If

            ' ----------
            If i > 0 Then
                s = i
                p = Int((i - 1) / 2)

                ' �p�G���˸`�I��{�b�`�I�j 
                Do While ((s >= 1) And (heap(p) > heap(s)))
                    swap(heap, p, s)   ' �洫 
                    s = p
                    p = Int((s - 1) / 2)   ' ���W�~��B�z 
                    If p < 0 Then Exit Do
                Loop
            End If
        Next
        For i = 0 To ValueSize - 1
            num(i) = heap(i)
        Next
    End Sub

    ' =========== Program Description ============================
    ' �{���W�� : heapsor  ��ƱƧǤ�k
    ' ============================================================
    Sub heapsort(ByRef num() As Integer)
        Dim i, m, p, s As Integer

        m = ValueSize - 1
        Do While (m > 0)
            swap(num, 0, m) ' �N�Ĥ@�Ӹ`�I�P�P��m�Ӹ`�I�洫 
            m -= 1
            p = 0
            s = 2 * p + 1
            ' ���@���̤j��n���վ� 
            Do While (s <= m)
                If ((s < m) And (num(s + 1) < num(s))) Then
                    s += 1
                End If
                If (num(p) <= num(s)) Then
                    Exit Do
                End If
                swap(num, p, s)
                p = s
                s = 2 * p + 1
            Loop

            ' ��n���վ�L����� 
            Console.Write("Sorting�G")
            For i = 0 To ValueSize - 1
                Console.Write(num(i) & " ")
            Next
            Console.WriteLine(" ")
        Loop
    End Sub

    ' =========== Program Description ============================
    ' �{���W�� : [����heap�Ƨ�]���s�� Click �ƥ�
    ' ============================================================
    Private Sub heapsort_but_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles heapsort_but.Click
        create_but.Enabled = False
        heapsort_but.Enabled = False
        heapsort(A)
    End Sub
End Class
