Sleipnir Version 1.41
Copyright(C) 2001-2002 by Yasuyuki Kashiwagi.
http://www20.pos.to/~sleipnir/
contact_sleipnir@msn.com


INTRODUCTION:
===============================================================================

Sleipnir is a customizable tabbed browser.
The latest version of Sleipnir can be downloaded from 

http://www20.pos.to/~sleipnir/

If you have any questions, comments or suggestions, feel free to contact me.


LICENSE:
===============================================================================

For using Sleipnir, You have to agree with the following conditions. 

- The author owns the full copyright to Sleipnir.
- The author assumes no responsibility, or gives any sort of guarantees for 
  damages that may occur from using Sleipnir.
- The author's permission is required for reproduction.


SYSTEM REQUIREMENTS:
===============================================================================

1)	Microsoft Windows 98/ME/2000/XP
2)	Internet Explorer 5.01 or higher


SUPPORT:
===============================================================================

Please visit Sleipnir Online Help - http://www20.pos.to/~sleipnir/help/eng/


INSTALLATION:
===============================================================================

There are no special installation requirements. Simply extract all the files in
the zip file to a directory where you want to install Sleipnir. Once 
installed, you can start Sleipnir anytime.


UNINSTALLATION:
===============================================================================

If Sleipnir is set as a default browser, cancel that through the Sleipnir 
options, before uninstalling. Then remove all Sleipnir files on your system.


HOW TO VERSION UP:
===============================================================================

Overwrite the files. 
If new menu items are added, menu will be reset.


COPYRIGHT:
===============================================================================

The author holds copyrights to Sleipnir, Favorites Editor and all attached 
documents.


UPDATED:
===============================================================================

Please see History.txt. (Provided in Japanese)

